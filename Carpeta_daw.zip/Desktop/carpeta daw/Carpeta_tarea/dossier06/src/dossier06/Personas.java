/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dossier06;

/**
 *
 * @author Dario Diaz
 */
public class Personas {

abstract class Persona {
    protected String nombre;
    protected String apellido1;
    protected String apellido2;
    protected int edad;
    protected int altura;
    protected double peso;

    public Persona(String nombre, String apellido1, String apellido2, int edad, int altura, double peso) {
        this.nombre = nombre;
        this.apellido1 = apellido1;
        this.apellido2 = apellido2;
        this.edad = edad;
        this.altura = altura;
        this.peso = peso;
    }

    @Override
    public String toString() {
        return "nombre=" + nombre + ", apellido1=" + apellido1 + ", apellido2=" + apellido2 + ", edad=" + edad + ", altura=" + altura + ", peso=" + peso;
    }
    
    abstract double calcularPesoIdeal();
    
    protected double calcularIMC(){
        double imc = 0;
        return imc;
    }
    
    
    
}

class Hombre extends Persona{

    public Hombre(String nombre, String apellido1, String apellido2, int edad, int altura, double peso) {
        super(nombre, apellido1, apellido2, edad, altura, peso);
    }

    @Override
    double calcularPesoIdeal() {
        double k = 4;
        double resultado = altura - 100 - ((100 - 150) / k);
        return resultado;
    }
    
}

class Mujer extends Persona{

    public Mujer(String nombre, String apellido1, String apellido2, int edad, int altura, double peso) {
        super(nombre, apellido1, apellido2, edad, altura, peso);
    }

    @Override
    double calcularPesoIdeal() {
        double k = 2;
        double resultado = altura - 100 - ((100 - 150) / k);
        return resultado;
    }
    
}

}