/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dossier06;

/**
 *
 * @author daw
 */
public class Persona {
String nombre;
String apellidos;
static int contador=0;
int  id;

public Persona (String nombre, String apellidos) {
this.nombre= nombre;
this.apellidos= apellidos;
}
public Persona (){id =++contador;}

    @Override
    public String toString() {
        return "Persona{" + "nombre=" + nombre + ", apellidos=" + apellidos + '}';
    }

}
class Alumno extends Persona {
String grupo;
double notaMedia;

public Alumno(String nombre, String apellidos, String grupo, double notaMedia) {
super(nombre, apellidos);
this.grupo= grupo;
this.notaMedia= notaMedia;
}

public Alumno (){}

    @Override
    public String toString() {
        return super.toString()+" "+notaMedia;
    }

}
class MainPersona {
    public static void main(String[] args) {
        Alumno alu2= new Alumno("Mario", "León","3",3
        );
        System.out.println(alu2);
    }

}