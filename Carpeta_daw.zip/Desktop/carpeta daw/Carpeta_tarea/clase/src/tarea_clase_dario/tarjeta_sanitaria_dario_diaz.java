/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tarea_clase_dario;

import java.util.Scanner;

/**
 *
 * @author Dario Diaz
 */
public class tarjeta_sanitaria_dario_diaz {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        System.out.println("Digame su nombre");
        String nombre = sc.nextLine();
        
        System.out.println("Digame su primer apellido");
        String apellido1 = sc.nextLine();
        
        System.out.println("Digame su segundo apellido");
        String apellido2 = sc.nextLine();
        
        System.out.println("Digame el dia de su nacimiento");
        int dia = sc.nextInt();
        
        System.out.println("Digame el mes de su nacimiento");
        int mes = sc.nextInt();
        
        System.out.println("Digame el año en el que nacio");
        int anio = sc.nextInt();
        
        System.out.println("Digame su sexo (M o F)");
        char sexo = (char) sc.nextShort();
        
        String array[] = {"a", "e", "i", "o", "u"};
        
        
        
  
        char apellidoSigla = apellido1.charAt(0);
        
        
        System.out.println(apellido1 + apellido2 + anio + mes + dia);
    }
}
