/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication3;

/**
 *
 * @author Dario Diaz
 */
public class Fraccion {
    private int numerador;
    private int denominador;
    
    private int mcd(int num1, int num2){
        return mcd(num1, num2);
    }
    
    public Fraccion(int num1, int num2){
        int mcd = mcd(num1, num2);
        this.numerador = num1/mcd;
        this.denominador = num2/mcd;
       
    }
    
    static boolean mayorQue(Fraccion fr1, Fraccion fr2){
        return fr1.toDouble() > fr2.toDouble();
    }
    
    static boolean menorQue(Fraccion fr1, Fraccion fr2){
         return fr1.toDouble() < fr2.toDouble();
    }
    
    static boolean igualQue(Fraccion fr1, Fraccion fr2){
         return fr1.toDouble() == fr2.toDouble();
    }
    
    
    public double toDouble(){
        return numerador/(double)denominador;
    }
    
    public Fraccion sumar(Fraccion fr1, Fraccion fr2){
        int mcm = (fr1.denominador * fr2.denominador)/mcd(fr1.denominador, fr2.denominador);
        
        int nuevoNumerador, nuevoDenominador;
        
        nuevoDenominador = mcm;
        
        nuevoNumerador = mcm/fr1.denominador*fr1.denominador + mcm/fr2.denominador*fr2.denominador;
        /*
        Fraccion resultado = new Fraccion(nuevoNumerador, nuevoDenominador);
        return resultado;
        ES lo mismo que lo siguiente:
        */
        return new Fraccion(nuevoNumerador, nuevoDenominador);
    }
    
        public Fraccion resta(Fraccion fr1, Fraccion fr2){
            Fraccion fr3 = new Fraccion(fr2.numerador*-1, fr2.denominador);
            return sumar(fr1, fr3);
        }
        
        public Fraccion invertir(){
            /*
            int nuevoNumerador = this.denominador;
            int nuevoDenominador = this.numerador;
            return new Fraccion(nuevoNumerador, nuevoDenominador);
            */
            return new Fraccion(denominador, numerador);
        }
        
        public static Fraccion multiplicar(Fraccion fr1, Fraccion fr2){
            int nuevoNumerador = fr1.numerador * fr2.numerador;
            int nuevoDenominador = fr1.denominador + fr2.denominador;
            return new Fraccion(nuevoNumerador, nuevoDenominador);
        }
    
    
}
