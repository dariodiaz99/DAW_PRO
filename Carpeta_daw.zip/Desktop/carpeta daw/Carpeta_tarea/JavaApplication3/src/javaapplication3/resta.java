/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication3;

/**
 *
 * @author Dario Diaz
 */
public class resta {
    public static int resta(int num1, int num2) {
        return num1 - num2;
    }
   
    public static String resta(String str1, String str2) {
        return str1.substring(0, str1.length() - str2.length());
    }
    
    public static void main(String[] args) {
        System.out.println(resta(10, 4));
        System.out.println(resta("hola mundo", "mundo"));
    }
    
}
