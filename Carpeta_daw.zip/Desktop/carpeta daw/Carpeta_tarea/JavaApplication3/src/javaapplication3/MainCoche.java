/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication3;

import java.util.Scanner;

/**
 *
 * @author Dario Diaz
 */
public class MainCoche {

    
//    public static void main(String[] args) {
//        String escenario = "----------";
//        
//        //Coche estanisCoche = new Coche();
//        
//        boolean finalizar = false;
//        
//        Scanner sc = new Scanner(System.in);
//        
//        do{
//            finalizar = Menu(sc, estanisCoche, finalizar);
//            int pos = estanisCoche.getPosicion();
//            String nuevoEscenario = "";
//            for (int i = 0; i < args.length; i++) {
//                if (pos == 1) {
//                    nuevoEscenario += estanisCoche.getNombre().charAt(0);
//                }else{
//                    nuevoEscenario += '-';
//                }
//            }
//            System.out.println(nuevoEscenario);
//            
//        }while(!finalizar);
//    }    
//
//    private static boolean Menu(Scanner sc, Coche estanisCoche, boolean finalizar) {
//        System.out.println("Menu: ");
//        System.out.println("1) Arrancar coche");
//        System.out.println("2) Apagar coche");
//        System.out.println("3) Quitar freno de mano");
//        System.out.println("4) poner freno de mano");
//        System.out.println("5) mover izquierda");
//        System.out.println("6) mover derecha");
//        System.out.println("7) Salir del programa");
//        System.out.print("Opción: ");
//        int opcion = sc.nextInt();
//        switch(opcion){
//            
//            case 1:
//                String arrancarCoche = estanisCoche.arrancarCoche();
//                System.out.println(arrancarCoche);
//                break;
//            
//            case 2: System.out.println("no se apaga");
//            break;
//            
//            case 3: String BajarFrenoMano = estanisCoche.bajarFrenoMano();
//            System.out.println(BajarFrenoMano);
//            break;
//            
//            case 4: String SubirFrenoMano = estanisCoche.subirFrenoDeMano();
//            System.out.println(SubirFrenoMano);
//            
//            case 5: System.out.println("¿Cuantos pasos?");
//            int pasos = sc.nextInt();
//            System.out.println(estanisCoche.moverCocheIzquierda(pasos));
//            break;
//            
//            case 6: System.out.println("¿Cuantos pasos?");
//            int pasos2 = sc.nextInt();
//            System.out.println(estanisCoche.moverCocheDerecha(pasos2));
//            break;
//            
//            case 7: finalizar = true;
//            break;
//        }
//        return finalizar;
//    }    
//
}
