/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication3;

/**
 *
 * @author Dario Diaz
 */

class Alumno{
    String nombre;
    int edad;
    
    static public String DIRECCION = "c/Las Cabezas nº7";
    
    void mostrar(){
        System.out.println("nombre: " + nombre + " edad: "+ edad + DIRECCION);
    }
    
    public static void aprobar(){
        System.out.println(1+(int)Math.random()*10);
    }
}


//class Perro{
//    double peso;
//    String nombre;
//    String raza;
//    private int edad;
//    private String pulmones;
//
//    void operarPulmones(String nuevosPulmones){
//        pulmones = nuevosPulmones;
//    }
//    
//    void mostrar(){
//        System.out.println("nombre: " + nombre + " raza: " + raza + 
//                " peso: " + peso + " " +" edad: "+ edad + pulmones );
//    }
//    
//    void cumplirAnios(){
//        edad++;
//    }
//    
//}

public class MiMain {
    public static void main(String[] args) {
        
        Alumno alu1 = new Alumno();
        Alumno alu2 = new Alumno();
        alu1.nombre = "Rufino";
        alu2.nombre = "Romina";
        alu1.edad = 20;
        alu2.edad = 21;
        
        alu1.mostrar();
        alu2.mostrar();
        
        System.out.println(Alumno.DIRECCION);
        
        Alumno.DIRECCION = "c/Bienvenido s/n";
        
        Alumno.aprobar();
        alu1.mostrar();
        alu2.mostrar();
        
        


//        Perro perro = new Perro();
//        
//        perro.nombre = "Fufi";
//        perro.raza = "labrador";
//        perro.peso = 30;
        
        
//        
//        Persona p = new Persona();
//        
//        p.apellido = "Diaz";
//        p.nombre = "Dario";
//        p.edad = 21;
//        
//        
//        System.out.println(p.nombre + " " + p.apellido + " edad: " + p.edad);
        
  }
}
      