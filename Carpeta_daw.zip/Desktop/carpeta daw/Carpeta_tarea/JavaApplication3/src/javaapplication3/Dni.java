/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication3;

/**
 *
 * @author Dario Diaz
 */
public class Dni {
    private int dniNum;
    private static final String letrasPosibles = "TRWAGMYFPDXBNJZSQVHLCKE";
    private char letra;
    
    public Dni(int dniNum){
        this.dniNum = dniNum;
        letra = calcularLetra(dniNum);
    }
    
    public Dni(String strDni){
        if(validarDni(strDni)){
            this.dniNum = Integer.parseInt(strDni.substring(0,8));
            this.letra = strDni.toUpperCase().charAt(strDni.length()-1);
        }else{
            //throw new Exception("no es un dni válido");
        }
    }
    
    
    public boolean validarDni(String strDni){
        boolean resultado = true;
        int numDni;
        try{
           numDni = Integer.parseInt(strDni.substring(0, 8));
           char letra = calcularLetra(numDni);
           char letraStrDni = strDni.toUpperCase().charAt(strDni.charAt(strDni.length()-1));
           resultado = letra == letraStrDni;
//           if (letra == letraStrDni){
//               resultado = true;
//           }else{
//               resultado = false;
//           }
        }catch(Exception ex){
           resultado = false;
        }
       return resultado;
    }
    
//    public char calcularLetra(){
//        int resto = this.dniNum % 23;
//        return letrasPosibles.charAt(resto);
//    }
    
    public static char calcularLetra(int dniNum){
        return letrasPosibles.charAt(dniNum%23);
    }
}
