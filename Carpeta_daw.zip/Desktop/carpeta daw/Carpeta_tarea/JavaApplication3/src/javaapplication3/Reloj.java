/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication3;

/**
 *
 * @author Dario Diaz
 */
public class Reloj {
    private int hora;
    private int minutos;
    private int segundos;
    String horaEstablecida;
    
    public int getHora() {
        return hora;
    }


    public void setHora(int hora) {
        this.hora = hora;
    }


    public int getMinutos() {
        return minutos;
    }


    public void setMinutos(int minutos) {
        this.minutos = minutos;
    }

    public int getSegundos() {
        return segundos;
    }

    public void setSegundos(int segundos) {
        this.segundos = segundos;
    }
    
    
    void establecerFormatoHora(int hora, int minutos, int segundos){
        System.out.println("Dame la hora que quieres establecer en el reloj");
        horaEstablecida = hora + ":" + minutos + ":" + segundos;
        
    }
    
//    public Reloj incrementarReloj(){
//        do{
//            if (segundos != 0){
//            this.segundos = segundos++;
//            if(segundos == 60){
//                segundos = 0;
//                int minutosIncrementados = minutos++;
//                if(minutosIncrementados == 60){
//                    minutosIncrementados = 0;
//                    int horasIncrementadas = hora++;
//                }
//            }
//            }
//        }while (this.hora == 24); 
//        return incrementarReloj();
//        
//    }
    
    public void incrementarHora(int horas){
       this.hora += horas;
       this.hora %= 24;
    }
    
    public void incrementarMinutos(int minuto){
        this.minutos += minuto;
        incrementarHora(this.minutos /60);
        this.minutos %= 60;
    }
    
    public void incrementarSegundo(int segundo){
        this.segundos += segundo;
        incrementarMinutos(this.segundos /60);
        this.segundos %= 60;
    }
    
    public static void main(String[] args) {
        
    }
}
