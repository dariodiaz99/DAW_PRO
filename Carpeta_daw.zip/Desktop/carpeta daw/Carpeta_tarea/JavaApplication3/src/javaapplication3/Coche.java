/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication3;

import java.util.Scanner;

/**
 *
 * @author Dario Diaz
 */
public class Coche {

    private String nombre;
    private boolean encendido;
    boolean apagado;
    private boolean frenoDeManoPuesto;
    private int posicion;
    private Maletero miMaletero;
    
    public Coche(String nom, double posX, double posY){
        
        miMaletero = new Maletero();
    }
    
    public String arrancarCoche() {
        String respuesta = "";
        if (!encendido) {
            encendido = true;
            respuesta = "ok! coche prendido";
        } else {
            respuesta = "No seas picapiedra y utiliza el motor";}
            return respuesta;
    }
    
    public String apagarCoche() {
        String respuesta = "";
        if (!apagado) {
            apagado = true;
            respuesta = "coche parado";
        } else {
            respuesta = "No seas tonto y gira la llave";}
            return respuesta;
    }
    
    public String subirFrenoDeMano() {
        String respuesta = "";
        if (!encendido) {
            encendido = true;
            respuesta = "ok! freno puesto";
        } else {
            respuesta = "No seas bruto....ya esta puesto";}
            return respuesta;
    }

        public String bajarFrenoMano(){
            String respuesta = "";
            if (!frenoDeManoPuesto){
                frenoDeManoPuesto = true;
                respuesta = "ok! freno quitado";
        }else{
            respuesta = "Cuidado, pon el freno de mano por seguridad";}
            
            return respuesta;
    
        }
        
        private String moverCoche(int posiciones){
            String respuesta = " ";
            if (encendido){
                if(frenoDeManoPuesto){
                    encendido = false;
                    respuesta = "freno puesto... me he calado";
                }else{
                    posicion += posiciones;
                    respuesta = "ok coche movido";
                }
            }else{
                respuesta = "coche apagado no se puede mover";
            }
            return respuesta;
        }
        
        public String estado(){
            return nombre + "encendido: " + encendido + posicion + "freno puesto: " + frenoDeManoPuesto ;
        }
        
        public String moverCocheIzquierda (int cantidad){
            return moverCoche(-1*cantidad);
        }
        
        public String moverCocheDerecha (int cantidad){
           return moverCoche(1*cantidad);
        }
        
        

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public boolean isEncendido() {
        return encendido;
    }

    public void setEncendido(boolean encendido) {
        this.encendido = encendido;
    }

    public boolean isFrenoDeManoPuesto() {
        return frenoDeManoPuesto;
    }

    public void setFrenoDeManoPuesto(boolean frenoDeManoPuesto) {
        this.frenoDeManoPuesto = frenoDeManoPuesto;
    }

    public int getPosicion() {
        return posicion;
    }

    public void setPosicion(int posicion) {
        this.posicion = posicion;
    }
    

}