/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication3;

/**
 *
 * @author Dario Diaz
 */
class Gato {

    private String nombre;
    private double garras;
    private int edad;
    private int patas = 4;
    private final String raza;
    private int peso;

    public Gato(String n, String r, int p) {
        raza = r;
        nombre = n;
        patas = 4;
        garras = 1;
        peso = p;
    }

    public void cumplirAnios() {
        edad++;
        garras += 2;
    }

    public void comer(int gramos) {
        peso += gramos;
    }

    public int getPatas() {
        return patas;
    }

    public void ronrronear() {
        System.out.println("ron ron ron");
    }

    public void maullar() {
        System.out.println("miauuuuuuuuuuuuuuuuuuuuuuu");
    }

    public void bufar() {
        System.out.println("FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF");
    }

    public void araniar() {
        garras--;
    }

    public int getpatas() {
        return patas;
    }

    void setnombre() {
        String array[] = {
            "Isidoro",
            "Felix",
            "Garfield",
            "Paca",
            "Pelusa",
            "Doraemon"
        };
    }

    public void mostrar() {
        System.out.println(
                "nombre: " + nombre
                + " edad: " + edad
                + " peso: " + peso
                + " raza: " + raza
                + " patas: " + patas
                + " garras: " + garras
        );
    }

}

public class Main2 {

    public static void main(String[] args) {
        Gato gato = new Gato("Felix", "egipcio", 2300);
        gato.mostrar();
    }
}
