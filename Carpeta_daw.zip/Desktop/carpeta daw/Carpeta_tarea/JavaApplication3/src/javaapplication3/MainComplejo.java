/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication3;

/**
 *
 * @author Dario Diaz
 */
public class MainComplejo {
    public static void main(String[] args) {
        Complejo c = new Complejo(0, 0);
        
        Complejo d = new Complejo(2, 3);
        
        Complejo resultado = Complejo.suma(c, d);
        
        Complejo resOpuesto = Complejo.opuesto(d);
        
        Complejo resResta = Complejo.resta(c, d);
        
        Complejo resOpuestoEstatico = Complejo.opuesto(d);
        
        //Complejo resOpuesto = d.opuesto();
    }
}
