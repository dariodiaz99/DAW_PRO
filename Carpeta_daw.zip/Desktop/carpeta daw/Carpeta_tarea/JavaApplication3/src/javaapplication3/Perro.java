/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication3;

/**
 *
 * @author Dario Diaz
 */
public class Perro {

    class perro{
        String nombre;
        String raza;
        int edad;
        
        perro(String n, String r, int e){
            nombre=n;
            raza=r;
            edad=e;
        }
        
        perro(String n, String r){
            nombre=n;
            raza=r;
            edad=-1;
        }
        
        perro(String n){
            nombre=n;
            raza= "Sin raza";
            edad=-1;
        }
        
    }
    
    public Perro(){
        perro perro1 = new perro("Fufi","bulldog",1);
        perro perro2 = new perro("Fufi1", "caniche");
        perro perro3 = new perro("Fufi");
    }
}
