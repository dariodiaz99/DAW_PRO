/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication3;

import java.util.Scanner;

/**
 *
 * @author Dario Diaz
 */
//class Conversor {
//    
//    
////
////    static double tasaDeCambio;
////
////    public Conversor(double c) {
////        tasaDeCambio = c;
////    }
////
////    static double euroToDolar(double euro) {
////        return euro/tasaDeCambio;
////    }
////    
////    static double dolarToEuro(double dolar){
////        return tasaDeCambio * dolar;
////    }
////    
////    void establecerTipo(double tipo){
////        tasaDeCambio = tipo;
////    }
////        
//}
//
//
//public class practica04 {
//    public static void main(String[] args) {
//        System.out.println("Introduce la cantidad de euros:");
//        Scanner sc = new Scanner(System.in);
//        
//        Conversor conversor = new Conversor(0.8615);
//        
//        double euros = sc.nextDouble();
//        
//        double dolar = conversor.euroToDolar(euros);
//        
//        System.out.println("Cantidad introducida fue: " + euros + "€"+ " y convertida a dolares es: " + Conversor.euroToDolar(euros) + "$");
//        
//        conversor.establecerTipo(0.93);
//        
//        dolar = conversor.euroToDolar(euros);
//        
//        System.out.println("tu cambio ahora es: " + dolar + "$");
//        
//    }
//}
