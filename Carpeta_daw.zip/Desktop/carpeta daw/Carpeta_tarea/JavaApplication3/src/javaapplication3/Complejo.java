/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication3;

/**
 *
 * @author Dario Diaz
 */
public class Complejo {
    public double real;
    public double imaginario;
    
    private static int n = 3;
    private static String constructor;
    
    
    public Complejo(double real, double imaginario){
        System.out.println("ha llamado al de 2 parámetros");
        this.real = real;
        this.imaginario = imaginario;
    }
    
    public Complejo(double real){
        this(real, 0);
        System.out.println("ha llamado al de un parámetro");
    }
    
    public Complejo(){
        this(0);
        System.out.println("ha llamado al de 0 parámetros");
    }
    
    public static Complejo suma(Complejo a, Complejo b){
        double real = a.real + b.real;
        double imaginario = a.imaginario + b.imaginario;
        return new Complejo(real, imaginario);
    }
    
    public static Complejo resta(Complejo a, Complejo b){
        double real = a.real - b.real;
        double imaginario = a.imaginario - b.imaginario;
        return new Complejo(real, imaginario);
    }
    
    public static Complejo opuesto(Complejo c){
        //return new Complejo(-d.real, -d.imaginario);
        double realOpuesto = -c.real;
        double imaginarioOpuesto =  -c.imaginario;
        return  new Complejo(realOpuesto, imaginarioOpuesto);
    }
    
    public Complejo opuesto(){
        return new Complejo(-this.real, -this.imaginario);
    }
    
    public Complejo suma(Complejo d){
        double realSuma = this.real + d.real;
        double imaginarioSuma = this.imaginario + d.imaginario;
        return new Complejo(realSuma, imaginarioSuma);
    }
    
    public Complejo(Complejo aCopiar){
        this.real = aCopiar.real;
        this.imaginario = aCopiar.imaginario;
    }
    
}
