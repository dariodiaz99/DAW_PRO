/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tareadeclase_dario_diaz;

/**
 *
 * @author Dario Diaz
 */
public class Fecha {

    private int Fecha;
    private String DiaSemana;

    Fecha(int i) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
        /**
     * @return the Fecha
     */
    public int getFecha() {
        return Fecha;
    }

    /**
     * @param Fecha the Fecha to set
     */
    public void setFecha(int Fecha) {
        this.Fecha = Fecha;
    }

    /**
     * @return the DiaSemana
     */
    public String getDiaSemana() {
        return DiaSemana;
    }

    /**
     * @param DiaSemana the DiaSemana to set
     */
    public void setDiaSemana(String DiaSemana) {
        this.DiaSemana = DiaSemana;
    }

    long toLong() {
        System.currentTimeMillis();
        return toLong();
    }
}
    
  