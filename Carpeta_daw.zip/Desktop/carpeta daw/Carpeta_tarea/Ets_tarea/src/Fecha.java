/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.text.SimpleDateFormat;
import java.util.Date;
/**
 *
 * @author Dario Diaz
 */

public class Fecha {
   SimpleDateFormat formato;
   Date hoy;

   public Fecha(){
      hoy = new Date();
   }

   public String DevuelveFecha(int tipo){/*1*/
      String cad = "";/*2*/
      switch (tipo) {/*3*/
      case 1:{/*4*/
         formato = new SimpleDateFormat("yyyy/MM");
         cad = formato.format(hoy);
         break;
      }
      case 2:{/*5*/
         formato = new SimpleDateFormat("MM/yyyy");
         cad = formato.format(hoy);
         break;
      }
      case 3:{/*6*/
         formato = new SimpleDateFormat("MM/yy");
         cad = formato.format(hoy);
         break;
      }
      default: {/*7*/
         cad = "ERROR";
      }
   }
   return cad;/*8*/
   }

}
