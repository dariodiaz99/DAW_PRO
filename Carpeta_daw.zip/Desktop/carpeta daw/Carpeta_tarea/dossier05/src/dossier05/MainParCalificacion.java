/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dossier05;

import java.util.ArrayList;

/**
 *
 * @author Dario Diaz
 */
public class MainParCalificacion {
    public static void main(String[] args) {
        
        Par<String,String> mipar = new Par<String,String>("España","Madrid");
        
        ArrayList<Par<String,String>>paises;
        
        ArrayList<ParCalificacion> array = new ArrayList<ParCalificacion>();
        
        paises = new ArrayList<Par<String,String>> ();
        
        
        array.add(new ParCalificacion("Ana", 8));
        array.add(new ParCalificacion("Paco", 7));
        array.add(new ParCalificacion("Marta", 9));
        
        for(ParCalificacion parCalificacion : array) {
            System.out.println(parCalificacion);
            parCalificacion.equals(args);
            
        }
    }
}
