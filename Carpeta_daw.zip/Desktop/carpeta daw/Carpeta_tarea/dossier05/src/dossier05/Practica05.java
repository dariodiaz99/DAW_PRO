/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dossier05;

/**
 *
 * @author Dario Diaz
 */
public class Practica05 {
    public static void main(String[] args) {
        int array[][] = new int[7][];
        for (int i = 0; i < array.length; i++) {
            array[i] = new int[i+1];
            int[] elementos = array[i];
            for (int j = 0; j < elementos.length; j++) {
                if (j == 0 || j == elementos.length -1) {
                    elementos[j] = 1;
                }else{
                   elementos[j]=array[i-1][j-1] + array[i-1][j];
                
            }
                System.out.print("\t"+elementos[j]);
                
            }
            System.out.println("");
            
        }
    }
}
