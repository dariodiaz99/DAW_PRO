/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dossier05;

import java.util.ArrayList;

/**
 *
 * @author Dario Diaz
 */
public class Practica18 {
    public static void main(String[] args) {
        ArrayList<Integer> arr1 = new ArrayList<Integer>(5);

        arr1.add(2);
        arr1.add(23);
        arr1.add(54);

        for (Integer num : arr1) {
            System.out.println(num);
        }
        System.out.println("Añadiendo");
        ArrayList<Integer> arr2 = new ArrayList<Integer>(5);
        arr2.add(14);
        arr2.add(20);
        arr2.add(243);
        for (Integer num : arr2) {
            System.out.println(num);
        }
        System.out.println("Añadiendo");
        arr1.addAll(arr2);
        for (Integer num : arr1) {
            System.out.println(num);
        }
        System.out.println("Añadiendo");
        arr1.removeAll(arr2);
        for (Integer num : arr1) {
            System.out.println(num);
        }
        System.out.println("Borrando");
        arr1.retainAll(arr2);

        for (Integer num : arr1) {
            System.out.println(num);
        }
    }
}
