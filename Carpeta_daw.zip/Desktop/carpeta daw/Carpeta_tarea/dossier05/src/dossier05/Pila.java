/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dossier05;

/**
 *
 * @author Dario Diaz
 * @param <T>
 */
public class Pila<T> {
    
    Object array[]; // <-------------
    int siguiente;
    
    public Pila(){
        this(10);
    }
    
    public Pila(int size){
        array = new Object[size]; // <-------------
    }
    
    public boolean add(T dato){ // <-------------
        boolean agregado;
        //controlar cuando la pila esta llena
        if (array.length > siguiente){
            array[siguiente] = dato;
            agregado = true;
            siguiente++;
        } else {
            agregado = false;
        }
        
        //dejar que la propia pila pete
        /*
        try{
            array[siguiente] = dato;
            agregado = true;
            siguiente++;
        }catch(Exception ex){
            agregado = false;
        }
        */
        return agregado;
    }
    
    public T pop() throws Exception{ // <-------------
        T devuelto = null; // <-------------
        if (siguiente <= 0){
            throw new Exception("Error");
        } else {
            devuelto = (T)array [--siguiente];
        }
        return devuelto;
    }
    
}