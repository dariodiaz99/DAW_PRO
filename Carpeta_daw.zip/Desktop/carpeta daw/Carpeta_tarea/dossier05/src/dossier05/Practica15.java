/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dossier05;

import java.util.ArrayList;
import java.util.Iterator;

/**
 *
 * @author Dario Diaz
 */
public class Practica15 {
    public static void main(String[] args) {
        ArrayList<String> arr = new ArrayList<String>();
        arr.add("hola");
        arr.add("caracola");  
        arr.add("coche");
    for(Iterator it =arr.iterator(); it.hasNext();){
        String dato = (String)it.next();
        if(dato.equals("Caracola")){
            it.remove();
            
        }else{
              System.out.println(dato);
        }
      
    }

    }
}
