/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dossier05;

/**
 *
 * @author Dario Diaz
 */
//crear una clase llamada palabrero y enviar desde un constructor algo como... 
public class palabrero1 {
    class palabrero{
        String region;
        String palabrasRegion[];
        
        public palabrero(String palabra, String...valores){
            this.region = region;
            int i = 0;
            //new String[valores.length];
            palabrasRegion = valores;
            /*for (String valor: valores){
                palabrasRegion[i] = valor;
                i++;
            }*/
        }
    }
   
}
