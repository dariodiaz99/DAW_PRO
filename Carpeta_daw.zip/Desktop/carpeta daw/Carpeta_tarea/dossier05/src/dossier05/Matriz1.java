/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dossier05;

/**
 *
 * @author Dario Diaz
 */
public class Matriz1 {
    class Matriz {
        int columnas;
        int filas;
        int datos[][];
        
        public string 
        
        
        public Matriz(int fil,int col ,int...valores){
            columnas = col;
            filas = fil;
            datos =new int[filas][columnas];
            int i=0,j=0;
            for(int val : valores){
                datos[i][j]= val;
                j++;
                if( j >= columnas){
                    i++;
                    j=0;
                }
            }
        }
    }
}
