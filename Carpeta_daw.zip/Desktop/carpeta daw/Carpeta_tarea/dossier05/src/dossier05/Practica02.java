/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dossier05;

import java.util.Scanner;

/**
 *
 * @author Dario Diaz
 */
public class Practica02 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int[][] array = new int[5][4];
        for (int i = 0; i < array.length; i++) {
            int[] fila = array[i];
            for (int j = 0; j < fila.length; j++) {
                System.out.println("Dame el dato " + j + " y de fila: " + i);
                fila[j] = sc.nextInt();
            }
        }
        mostrarArray(array);
        maximoMinimo(array);
    }

    public static void maximoMinimo(int array[][]) {
        int mayor = -1;
        int menor = 200;
        int posicionMayor = 0;
        int posYmayor = 0;
        int posXmenor = 0;
        int posYmenor = 0;
        for (int i = 0; i < array.length; i++) {
            int[] fila = array[i];
            for (int j = 0; j < fila.length; j++) {
                if (fila[j] > mayor) {
                    mayor = fila[j];
                    posicionMayor = i;
                    posYmayor = j;
                }
                if (fila[j] < menor) {
                    menor = fila[j];
                    posXmenor = i;
                    posYmenor = j;
                }
            }
        }
        System.out.println("mayor: (  " + posicionMayor + " , " + posYmayor + ") menor : (  " + posXmenor + " , " + posYmenor + ")");
    }

    public static void mostrarArray(int array[][]) {
        int i = 0;
        for (int[] fila : array) {
            for (int dato : fila) {
                System.out.print(" " + dato);
            }
            System.out.println("");
        }
    }
}
