/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dossier05;

import java.util.Scanner;

/**
 *
 * @author Dario Diaz
 */
public class Practica06 {
    public static void main(String[] args) {
        int matriza[][] = new int[3][3];
        int matrizb[][] = new int[3][3];
        int matrizc[][] = new int[3][3];
        int i, j;

        Scanner cin = new Scanner(System.in);

        System.out.println("Datos de la Matriz A :");

        for (i = 0; i <= 2; i++) {
            for (j = 0; j <= 2; j++) {
                System.out.print("Escribir valor " + i + " , " + j + " : ");
                matriza[i][j] = cin.nextInt();
            }
        }

        System.out.println("Datos de la Matriz B :");

        for (i = 0; i <= 2; i++) {
            for (j = 0; j <= 2; j++) {
                System.out.print("Escribir valor " + i + " , " + j + " : ");
                matrizb[i][j] = cin.nextInt();
            }
        }

        for (i = 0; i <= 2; i++) {
            for (j = 0; j <= 2; j++) {
                matrizc[i][j] = matriza[i][j] + matrizb[i][j];
            }
        }

        System.out.println("Matriz resultante de la suma :");
        for (i = 0; i <= 2; i++) {
            System.out.print("[ ");
            for (j = 0; j <= 2; j++) {
                System.out.print(matrizc[i][j]+" ");
            }
            System.out.println("]");

        }
    }
}

