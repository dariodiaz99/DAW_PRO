/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dossier05;

/**
 *
 * @author Dario Diaz
 */
class serVivo {
int edad;
int vida;
public void morir(){
    System.out.println("Adios mundo cruel");
}
   
}

class ReinoAnimal extends serVivo{
 String nombre;
    public ReinoAnimal(){
            System.out.println("soy un animal");
}
}

class Mamifero extends ReinoAnimal{
    
}

class Ballena extends Mamifero{
    int peso;
    void ballenato (){
        System.out.println("ballenato");
    }

    @Override
    public String toString() {
        return "Ballena{" + "peso=" + peso + '}';
    }

    public void setPeso(int peso) {
        this.peso = peso;
    }
    
    
}

public class SerVivo {
    public static void main(String[] args) {
        Ballena ballena = new Ballena();
        ballena.setPeso(8);
        System.out.println(ballena);
    }
}
