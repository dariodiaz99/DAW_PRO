/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dossier05;

/**
 *
 * @author Dario Diaz
 */
public class Practica04 {
    public static void main(String[] args) {
        int array[][] = new int[20][];
        array[0] = new int[1];
        array[0][0] = 0;
        for (int i = 0; i < array.length; i++) {
            array[i] = new int[i];
            array[i][0] = array[i-1][array[i-1].length - 1] + 1;
            for (int j = 1; j < array.length; j++) {
                array[i][j] = array[i][j-1]+1;
            }
        }
        
        for (int[] fila : array) {
            for (int i : fila) {
                System.out.println(i);
            }
        }
            
    }
}
