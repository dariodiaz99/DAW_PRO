/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dossier05;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author Dario Diaz
 */
public class Loteria {
    
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        HashMap<Integer, Integer> loteria = new HashMap<Integer, Integer>();
        Random rnd = new Random();
        
//        Scanner sc = new Scanner(System.in);
//        for (;premiados.size() < 10;) {
//            premiados.add(rnd.nextInt(101));
//        }
//        
//        System.out.println("ahora la pregunta real al usuario");
//        
//        System.out.println("introduce el numero: ");
//        int numIntro = sc.nextInt();sc.nextLine();
//        if (premiados.contains(numIntro)) {
//            System.out.println("El número está premiado");
//        }
        
        
        for (Integer i = 1; i < 10; i++) {
            Integer numero = rnd.nextInt(99)+1;
            loteria.put(i, numero);
            System.out.println(loteria);
        }
        
        System.out.println("Introduce tu numero");
        int numIntro = sc.nextInt();
        for (Map.Entry<Integer, Integer> entry : loteria.entrySet()) {
            Integer key = entry.getKey();
            System.out.println("Premiado");
        }
        
    }

}
