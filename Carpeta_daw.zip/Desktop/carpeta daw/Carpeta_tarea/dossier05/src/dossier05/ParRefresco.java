/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dossier05;

import java.util.ArrayList;
import java.util.Scanner;
import javafx.util.Pair;

/**
 *
 * @author Dario Diaz
 */
public class ParRefresco {
    //Crear programa para almacenar, de cada refresco guardar su nombre, calorias
    //hacer menu que nos permita introducir la cantidad de refresco que queramos y para cuando se escriba fin.
    
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Bienvenido a Lista de Refrescos favoritos");
        boolean fin = false;
        
        while (!fin){
            System.out.println("Introduce la cantidad de refrescos que quieras y sus calorias");
            System.out.println("Para acabar y ver el resumen, escribe fin");
           
            Pair<String, Integer> unRefresco = new Pair("Cocacola", 125);
            
            ArrayList< Pair<String, Integer> > ListaRefresco;
            ListaRefresco = new ArrayList<Pair<String, Integer>>();
            
            //ListaRefresco.add(unRefresco);
            ListaRefresco.add(new Pair<String, Integer>(nombre, peso));
            for (Pair<String, Integer> refresco : ListaRefresco) {
                System.out.println(refresco);
                
            }
            
        } 
    }
}
