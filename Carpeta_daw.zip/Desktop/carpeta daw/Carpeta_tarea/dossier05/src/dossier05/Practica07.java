/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dossier05;

/**
 *
 * @author Dario Diaz
 */
public class Practica07 {
    public static void main(String[] args) {
        int array[] = {20, 33, 54, 53, 6, 4, 21, 1,};

        StringBuilder textoCadena = new StringBuilder();

        for (int i = 0; i < array.length; i++) {
            textoCadena.append(array[i] + " ");
        }
        System.out.println(textoCadena);
        textoCadena.delete(1, 3);
        System.out.println(textoCadena);
        textoCadena.insert(3, " Inserta  ");
        System.out.println(textoCadena);
        textoCadena.replace(1, 20, " Reemplaza ");
        System.out.println(textoCadena);
    }
}
