/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dossier05;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author Dario Diaz
 */
public class Practica08 {
    //"^[A-Z][a-z]+-[2-9][0-9]-[a-z]{3}$"
    public static void main(String[] args) {
        Pattern p = Pattern.compile("[A-Z][a-z]+-[2-9][0-9]-[a-z][a-z][a-z]");
        Matcher m = p.matcher("X123456789Z Y00110011M 999999T");
        while (m.find()) {
            System.out.println("Letra inicial (opcional):" + m.group(1));
            System.out.println("Número:" + m.group(2));
            System.out.println("Letra:" + m.group(3));
        }
    }
}
