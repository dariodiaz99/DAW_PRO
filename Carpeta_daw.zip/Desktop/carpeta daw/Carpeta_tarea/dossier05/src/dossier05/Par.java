/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dossier05;

/**
 *
 * @author Dario Diaz
 */
public class Par<T, E> {
   
    private T clave;
    private E valor;
    
    public Par(T clave, E valor){
        this.clave = clave;
        this.valor = valor;
    }
    
    public String toString(){
        String resultado = "" ;
        resultado = "" + clave + "=>" + valor;
        return;
    }
    
    public E getValor(){
        return valor;
    }
    
    public E setValor(){
        return valor;
    }
    
    public T getClave(){
        return clave;
    }
    
    public T setClave(){
        return clave;
    }
    
    
    
}
