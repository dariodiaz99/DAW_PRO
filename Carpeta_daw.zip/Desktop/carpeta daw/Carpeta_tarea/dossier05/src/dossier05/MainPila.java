/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dossier05;

import java.util.Scanner;

/**
 *
 * @author Dario Diaz
 */
public class MainPila {
    public static void main(String[] args) {
        //PilaGenerica pila = new PilaGenerica(20);
        Scanner sc = new Scanner(System.in);
        System.out.println("Dame trabajo...");
        int trabajo = sc.nextInt();
        Pila.add(trabajo);
        Pila.add(3);
        Pila.add(5);
        
        System.out.println();
        
        Pila<String> pila1 = new PilaGenerica(10);
        Pila.add("Hola");
        Pila.add("Hoy");
        
        try {
            System.out.println(PilaGenerica.pop());
        } catch (Exception ex) {
            System.out.println("Pila vacía");
        }
    }
    
}
