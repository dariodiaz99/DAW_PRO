/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dossier05;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
/**
 *
 * @author Dario Diaz
*/
class Persona implements Comparable<Persona> {

    private String nombre;
    private String apellido;
    private int edad;

    Persona(String nombre, String apellido, int edad) {
        this.nombre = nombre;-
        this.apellido = apellido;
        this.edad = edad;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    @Override
    public String toString() {
        return nombre + " " + apellido + " edad: " + edad;
    }

    @Override
    public int compareTo(Persona p) {
        return this.nombre.toLowerCase().compareTo(p.nombre.toLowerCase());
    }

}

public class sort {

    public static void main(String[] args) {
//        int[] arr = {8, 1, 11, 5, 21, 10, 4, 15};
//        Arrays.sort(arr);
//        for (int i = 0; i < arr.length; i++) {
//            System.out.println(arr[i]);
//        }

//        ArrayList<Integer> arl = new ArrayList<Integer>(10);
//        arl.add(8);
//        arl.add(1);
//        arl.add(11);
//        arl.add(5);
//        arl.add(21);
//        arl.add(10);
//        arl.add(4);
//        arl.add(15);
////antes de ordenar:
//        for (Integer num : arl) {
//            System.out.print(num + " ");
//        }
//        System.out.println("");
//        Collections.sort(arl);
////ya ordenado:
//        for (Integer num : arl) {
//            System.out.print(num + " ");
//        }
        ArrayList<Persona> personas = new ArrayList<>(3);
        personas.add(new Persona("Marta", "León", 25));
        personas.add(new Persona("Julián", "Luz", 20));
        personas.add(new Persona("Pilar", "Ramos", 29));
        Collections.sort(personas);
        for (Persona p : personas) {
            System.out.println(p);
        }

    }
}
