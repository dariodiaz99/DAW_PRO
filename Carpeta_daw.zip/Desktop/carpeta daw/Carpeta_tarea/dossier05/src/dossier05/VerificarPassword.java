/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dossier05;

import java.util.Scanner;


/**
 *
 * @author Dario Diaz
 */
public class VerificarPassword {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        System.out.println("Prueba una contraseña:A ");
        String password = sc.nextLine();
                
        boolean aceptado = false;
        
        if (password.length() >= 8) {
           // && password.matches("^.*[0-9].*")
           // && password.matches("^.*[A-Z].*")
           // && password.matches("^.*[^\\W].*")
           // && password.matches("^.*[a-z].*");
            
            
            /*if(password.matches("^.*[0-9].*")){
                if(password.matches("^.*[A-Z].*")) {
                    if (password.matches("^.*[^\\W].*")) {
                        if (password.matches("^.*[a-z].*")) {
                            aceptado = true;
                        }
                    }
                }
            }*/
        }
        System.out.println("La expresión es: " + ((aceptado)?"Válida":"errónea"));
    }
}