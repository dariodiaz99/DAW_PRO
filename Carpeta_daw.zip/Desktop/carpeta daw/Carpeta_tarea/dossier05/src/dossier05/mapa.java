/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dossier05;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 *
 * @author Dario Diaz
 */
public class mapa {

    public static void main(String[] args) {
         HashMap<String,Double> mapa=new HashMap<String,Double>();
         mapa.put("Ana",9.2);
         mapa.put("Luis",8.5);
         mapa.put("Marta",6.0);
         mapa.put("Marco",5.5);
         mapa.put("Lidia",8.0);
         
         for (String clave : mapa.keySet()) {
             System.out.println("Clave" + clave + "Value: " + mapa.get(clave));
            
        }
         
         Iterator it = mapa.entrySet().iterator();
         while(it.hasNext()){
             Map.Entry<String, Double> entry =(Map.Entry<String, Double>) it.next();
         System.out.println("Clave="+entry.getKey()+", Valor="+entry.getValue());// it.remove();}
         }
    }
    
}
