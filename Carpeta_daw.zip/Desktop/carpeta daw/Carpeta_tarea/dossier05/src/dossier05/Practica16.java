/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dossier05;

import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

/**
 *
 * @author Dario Diaz
 */
public class Practica16 {

    public static void main(String[] args) {
        TreeMap<String, String> DiccionarioCastellano = new TreeMap<String, String>();
        DiccionarioCastellano.put("Hola", "Hello");
        DiccionarioCastellano.put("Adios", "Bye");
        DiccionarioCastellano.put("Rojo", "Red");
        DiccionarioCastellano.put("Azul", "Blue");
        DiccionarioCastellano.put("Coche", "Car");
        DiccionarioCastellano.put("Arbol", "Tree");
        DiccionarioCastellano.put("Naranja", "Orange");
        DiccionarioCastellano.put("Cielo", "Sky");
        DiccionarioCastellano.put("Pelota", "Ball");
        DiccionarioCastellano.put("Bolso", "Bag");
      
        
        String entradaUsuario = "Rojo";
        
        System.out.println(DiccionarioCastellano.get(entradaUsuario));
        
        
        TreeMap<String, String> DiccionarioIngles = new TreeMap<String, String>();
        for (String castellano: DiccionarioCastellano.keySet()) {
            DiccionarioIngles.put(DiccionarioCastellano.get(castellano), castellano);
        }
        
        System.out.println(DiccionarioIngles.get("Blue"));
    }
}
