/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dossier05;

/**
 *
 * @author Dario Diaz
 */
public class Practica01 {
     public static void main(String[] args) {
        int array[] = {5, 3, 2, 9, 8};
        for (int elemento : array) {
            elemento = 20;
            System.out.println(elemento);   
            //No se modifica debido a que es una variable local.
        }
    }
}
