/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dossier05;

import java.util.ArrayList;
import java.util.Random;

/**
 *
 * @author Dario Diaz
 */
public class Ejemplo_uso_arraylist {
    public static void main(String[] args) {
        Random rnd =new Random();
        ArrayList<Integer> al =new ArrayList<>(10);for(int i=0;i<8;i++)
        al.add(rnd.nextInt(100));
        
        for(int num : al){
                System.out.println(num);
        }
    }
}
