/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dossier05;

import java.util.HashMap;
import java.util.TreeMap;

/**
 *
 * @author Dario Diaz
 */
public class Practica17 {
    public static void main(String[] args) {

        HashMap<String, String> diccionarioCastellano = new HashMap<>();
        diccionarioCastellano.put("coche", "car");
        diccionarioCastellano.put("rojo", "red");
        diccionarioCastellano.put("blue", "azul");

        String entradaUsuario = "blue";
        HashMap<String, String> diccionarioingles = new HashMap<>();
        for (String castellano : diccionarioCastellano.keySet()) {
            diccionarioingles.put(
                    diccionarioCastellano.get(castellano), castellano
            );
        }
        System.out.println(
                diccionarioingles.get("azul")
        );
        TreeMap<String, String> Diccionario2 = new TreeMap<String, String>();
        Diccionario2.put("2", "Dos");
        Diccionario2.put("1", "Uno");
        Diccionario2.put("1", "Uno1"); //Se queda con la ultima palabra metido por el teclado
        Diccionario2.put("3", "Cuatro");
        Diccionario2.put("5", "Cinco");
        Diccionario2.put("4", "Cuatro");
        System.out.println("" + Diccionario2);
        System.out.println("Valor devuelto: " + Diccionario2.put("6", "Seis"));
        System.out.println("Valor devuelto: " + Diccionario2.put("3", "Tres"));
        System.out.println("" + Diccionario2); // {1=One, 2=Two, 3=Three,
        for (String palabra : Diccionario2.keySet()) {
            System.out.println(palabra + " " + Diccionario2.get(palabra));
        }
    }
}
