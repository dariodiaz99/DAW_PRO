/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dossier05;

/**
 *
 * @author Dario Diaz
 */
public class MainPalabrero {
    public static void main(String[] args) {
        palabrero mipalabrero = new palabrero("Canarias"
                , "Guachinche"
                , "cotufa"
                , "burra"
                , "tonique"
                , "fechillo");
         System.out.println("Palabras de: ");
         System.out.println(mipalabrero.region());
         System.out.println(mipalabrero.getLista());
    }
     
}
