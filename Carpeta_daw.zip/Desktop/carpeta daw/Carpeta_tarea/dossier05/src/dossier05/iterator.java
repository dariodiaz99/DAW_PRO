/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dossier05;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;

/**
 *
 * @author Dario Diaz
 */
public class iterator {

    public static void main(String[] args) {
        ArrayList<Double> miArray = new ArrayList<Double>();
        for (int i = 0; i < 10; i++) {
            Random rnd = new Random();
            miArray.add(new Double (rnd.nextInt(20)));
        }
        
        Iterator<Double> iterator = miArray.iterator();
    
        while (iterator.hasNext()) {            
            Double dato = iterator.next();
            System.out.println(dato);
        }
        
        for (Iterator it = miArray.iterator(); it.hasNext();) {
            int numero = (int) it.next();
            System.out.println(numero);
            it.remove();
            
            for (Double integer: miArray){
                System.out.println(" " + integer);
            }
            System.out.println("");
        }
    }
}