/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dossier05;

import com.sun.org.apache.xalan.internal.xsltc.compiler.Template;

/**
 *
 * @author Dario Diaz
 */
public class MainNodo {
    public static void main(String[] args) {
        Nodo inicio = new Nodo();
        inicio.dato = 3;
        
        Nodo dato1 = new Nodo();
        dato1.dato = 9;
        
        inicio.next = dato1;
        
        Nodo dato2 = new Nodo();
        dato2.dato = 23;
        
        dato1.next = dato2;
        
        Nodo dato3 = new Nodo();
        dato3.dato = 12;
        
        //dato3.next = "Introducir numero";
        //dato3.next = dato1.dato;
        
        dato1.next = dato3;
        dato3.next = dato2;
        //recorrer la lista
        
        Nodo recorrer = inicio;
        while (recorrer != null){
            System.out.println(recorrer.dato);
            recorrer = recorrer.next;
        }
    }
}


//ListaEnlazada lista = new listaEnlazada();
//sout("La lista contiene:")
// 
//Lista.mostrar();
//Lista.add(num);
//boolean borrar = Lista.borrar(num);

//sout (Lista.contiene(num));


