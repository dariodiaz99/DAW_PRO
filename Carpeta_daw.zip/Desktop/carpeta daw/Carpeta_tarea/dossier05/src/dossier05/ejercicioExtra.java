/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dossier05;

import java.util.ArrayList;
import java.util.Random;

/**
 *
 * @author Dario Diaz
 */
public class ejercicioExtra {
    // hacer un bucle que genere de 0 a 100, 10 numeros aleatorios y que los meta en un arrayList
    //Despues, borrar todos los numeros impares;
    
    
    // para detectar que es un numero impar, numero != char.at(numero)%2 == 0
    public static void main(String[] args) {
        ArrayList<Integer> miArray = new ArrayList<Integer>();
        for (int i = 0; i < 10; i++) {
            Random rnd = new Random();
            miArray.add(new Integer (rnd.nextInt(101)));   
        }
        
        for (Integer integer : miArray) {
            System.out.println(integer);
        }
        
        for (int i = 0; i < miArray.size(); i++) {
            if (miArray.get(i) % 2 == 0 ) {
                System.out.println("");
            }
            
        }

    }

    
}
