/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dossier05;

import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author Dario Diaz
 */
public class Practica11 {
    public static void main(String[] args) {
        System.out.println("Ecriba las frases del día");
        Scanner sc = new Scanner(System.in);
        int i = 1;
        String frase = "";
        ArrayList<String> al = new ArrayList<>(10);
        frase = sc.nextLine();
        while (frase.toLowerCase().equals("fin")) {
            System.out.println("Dime tu frase" + ++i);
            frase = sc.nextLine();
        }
        Random rnd = new Random();
        System.out.println(
                al.get(rnd.nextInt(al.size())
                )
        );
    }
}
