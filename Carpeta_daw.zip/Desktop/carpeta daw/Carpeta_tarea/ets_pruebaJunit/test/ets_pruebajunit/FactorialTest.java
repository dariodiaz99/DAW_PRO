/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ets_pruebajunit;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Dario Diaz
 */
public class FactorialTest {
    
    public FactorialTest() {
    }

    /**
     * Test of calculo method, of class Factorial.
     */
    @Test
    public void testCalculo() {
        System.out.println("calculo");
        int n = 5;
        int expResult = 120;
        int result = Factorial.calculo(n);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }
    
    @Test(excepted=java.lang.ArithmeticException.class)
    public void testDivide0(){
        Calculadora calcu = new Calculadora(20, 0);
        Integer resultado = calcu.divide0();
    }
    
    
}
