/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.util.Collection;
import org.junit.After;
import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.runners.Parameterized;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import java.util.Arrays;
import java.util.Collection;
import org.junit.After;
import org.junit.Test;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;

/*
 * @author Dario
 */
@RunWith(Parameterized.class)
public class CalculadoraTest {
    private int num1;
    private int num2;
    private int resul;
    private Calculadora c;

    public CalculadoraTest(int num1, int num2, int resul) {
        this.num1 = num1;
        this.num2 = num2;
        this.resul = resul;
    }

    @Parameters
    public static Collection<Object[]> numeros() {
        return Arrays.asList(new Object[][] {
            { 20, 10, 2}, { 30, -2, -15 }, { 5, 2, 3 }
        });
    }
    
    @Before
    public void setUp() throws Exception {
        c = new Calculadora(15, 5);
    }

    @After
    public void tearDown() throws Exception {
        c = null;
    }

    /* Test of suma method, of class Calculadora
        c = null;
    }

    /* Test of suma method, of class Calculadora

        private Calculadora(int i, int i0) {
            throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }
.
     */
    @Test
    public void testSuma() {
        System.out.println("suma");
        int expResult = 20;
        Calculadora calc = new Calculadora(num1, num2);
        int result = calc.suma();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
    }

    /* Test of resta method, of class Calculadora.
     */
    @Test
    public void testResta() {
        System.out.println("resta");
        int expResult = 10;
        Calculadora calc = new Calculadora(num1, num2);
        int result = calc.resta();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
    }

    /* Test of multiplicacion method, of class Calculadora.
     */
    @Test
    public void testMultiplicacion() {
        System.out.println("multiplicacion");
        int expResult = 75;
        Calculadora calc = new Calculadora(num1, num2);
        int result = calc.multiplica();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
    }

    /**
     * Test of division method, of class Calculadora.
     */
    @Test
    public void testDivision() {
        System.out.println("division");
        Calculadora calc = new Calculadora(num1, num2);
        int expResult = resul;
        int result = calc.divide();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
    }

    @Ignore
    public void testException() {
        try {
            int expResult = 3;
            Calculadora calc = new Calculadora(num1, num2);
            int result = calc.divide();
            assertEquals(expResult, result);
            // TODO review the generated test code and remove the default call to fail.
            fail("Excepción no ejecutada");
        } catch (ArithmeticException ex) {
            System.out.println("Excepción controlada");
        }
    }

}