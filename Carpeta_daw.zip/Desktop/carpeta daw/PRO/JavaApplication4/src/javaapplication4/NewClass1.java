/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication4;


/**
 *
 * @author dario
 */
public class NewClass1 {
    public static void main(String[] args) {
        // TODO code application logic here
        int aleatorio = (int)(Math.random() * 10); 
        
        System.out.println(aleatorio);
    }
}
