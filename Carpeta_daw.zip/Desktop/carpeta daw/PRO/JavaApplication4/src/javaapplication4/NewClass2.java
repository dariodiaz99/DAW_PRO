/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication4;

import java.util.Scanner;
/**
 *
 * @author dario
 */
public class NewClass2 {
    public static void main(String args[]){
        System.out.println("Introduce un texto o frase");
        Scanner scanner = new Scanner(System.in);
        String texto = scanner.nextLine();
        System.out.println(texto);
    }
}
