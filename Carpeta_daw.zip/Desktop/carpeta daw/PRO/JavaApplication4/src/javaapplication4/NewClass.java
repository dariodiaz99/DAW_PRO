/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication4;

import java.util.Scanner;

/**
 *
 * @author dario
 */
public class NewClass {
    public static void main(String[] args) {
        // TODO code application logic here
       System.out.println("Dime tu edad");
       Scanner scanner = new Scanner(System.in); 
       int edad = scanner.nextInt();
       
       String mayorDeEdad = (edad >= 18)? "adulto":"no adulto";
       System.out.println("mayorDeEdad dice: " + mayorDeEdad);
        
        
    }
}
