/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication5;

/**
 *
 * @author dario
 */
public class JavaApplication5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        double nota = 7.9;
        
        if( nota > 5 || nota == 5){
            int calificacion = (int)Math.round(nota);
            System.out.println("el valor era mayor que 5");
        }else{
            int calificacion = 5;
            System.out.println("el valor era menor que 5");
        }
        
        int calificacion = (nota > 5)? (int)Math.round(nota) : 5;
        System.out.println("la nota final es: " + calificacion);
    }
    
}
