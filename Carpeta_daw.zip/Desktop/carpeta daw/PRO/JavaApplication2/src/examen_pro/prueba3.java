/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package examen_pro;

/**
 *
 * @author Dario Diaz
 */
public class prueba3 {
    public static void main(String[] args) {
         
        String sinCifrar = "yakuza";
         
        int paso = 2;
        
        String cifrada = "";
        for (int i = 0; i < sinCifrar.length(); i++) {
                char cifrado = (char)(sinCifrar.charAt(i) + paso);
                cifrado = (char)('a' + (cifrado - 'a')%('z'-'a' + 1));
                cifrada += cifrado;
            }
            
            System.out.println(cifrada);
            
        }
//        for (int i = 0; i < args.length; i++) {
//            char cifrado = (char)(sinCifrar.charAt(i) + paso);
//            cifrado = (char)((cifrado > 'z')? 'a' + cifrado - 'z' -1 : cifrado);
//            cifrada += cifrado;
//        }
    }
    
 
