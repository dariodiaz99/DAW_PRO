/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package examen_pro;

import jdk.nashorn.internal.objects.NativeString;

/**
 *
 * @author Dario Diaz
 */
public class practica2 {
    public static void main(String[] args) {
        String strNum = "12345678";
        int array[] = new int[strNum.length()];
        for (int i = 0; i < strNum.length(); i++) {
            String aux = strNum.substring(i, i+1);
            int num = Integer.parseInt(aux);
            array[i] = num;
        }
        
        int sumaMaxima = 0;
        int a, b , c;
        for (int i = 1; i < array.length-1; i++) {
            int sumaActual = array[i-1]
                    + array[i] 
                    + array[i+1];
            if (sumaMaxima < sumaActual) {
                sumaMaxima = sumaActual;
                a = array[i-1];
                b = array[i];
                c = array[i+1];
            }
            System.out.println(sumaMaxima);
        }
    }
}
