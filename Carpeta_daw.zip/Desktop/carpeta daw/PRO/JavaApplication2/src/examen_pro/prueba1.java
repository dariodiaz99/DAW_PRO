/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package examen_pro;

/**
 *
 * @author Dario Diaz
 */
public class prueba1 {
    static double raiz(double num){
        double resultado = 0;
        if(num < 0){
            throw new ArithmeticException("lo que sea");
        }
        else{
            resultado = Math.sqrt(num);
        }
        return resultado;
    }
    
    public static void main(String[] args) {
        try {
            System.out.println(raiz(-20));
        } catch (ArithmeticException ae) {
            System.out.println("No admite raiz negativa");
        }
    }
}
