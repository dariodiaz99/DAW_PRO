package javaapplication2;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
// */
//package javaapplication20;
//
//import java.util.Random;

///**
// * @param size tamaño del array que vamos a generar
// * @param minAleatorio valor minimo aleatorio posible en el array
// * @param maxAleatorio valor maximo aleatorio posible en el array
// * @return el array deseado
// * @author dario
// */
//public class practica12 {
//    
//    public static int [] generarArrayAleatorio(int size, int minAleatorio, int maxAleatorio){
//        int array[] = new int[size];
//        Random rnd = new Random();
//        for (int i = 0; array.length; i++){
//            array[i] = rnd.nextInt(maxAleatorio - minAleatorio) + minAleatorio;
//        }
//        return array;
//    }
//    
//    public static void main(String[] args) {
//        int [] array = generarArrayAleatorio(20, 10, 50);
//       
//        int menores[] = new int [5];
//        for(int i = 0; i < menores.length; i++) {
//           menores[i] = array[i];
//        }
//       
//        for (int j = menores.length; j < array.length; j++) {
//           
//             //buscamos el número mayor del array de menores
//            int mayorDeMenores = menores[0];
//            int posicionMayor = 0;
//            for (int i = 0; i < menores.length; i++) {
//                if(mayorDeMenores < menores[i]){
//                    mayorDeMenores = menores[i];
//                    posicionMayor = i;
//                }
//            }
//       
//            int i = menores.length;
//            if(mayorDeMenores > array[j]){
//                menores[posicionMayor] = array[i];
//            }   
//        }
//    }
//}
//INCOMPLETO
