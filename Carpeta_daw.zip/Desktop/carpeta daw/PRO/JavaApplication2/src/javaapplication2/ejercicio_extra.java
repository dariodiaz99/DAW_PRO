/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication2;

import java.util.Scanner;

/**
 * usuario introduce un texto y denominar si el usuario ha introducido un número entero.(bucle for con .length())
 * si hay un numero, visualizar hay un numero entero. sino, no se lo que hay. (numero entero positivo o no lo es).
 * @author dario
 */
public class ejercicio_extra {

    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);
        
        System.out.println("Dame una frase mezclando digitos");
        String posibleNum = sc.nextLine();
        boolean esUnNum = isInt(posibleNum);
            
            if (esUnNum){
                System.out.println("número entero positivo");
            }else{
                System.out.println("no es un número positivo");
            }
    }

    private static boolean isInt(String posibleNum) {
        boolean esUnNum = true;
        boolean neg = false;
        int i;
        
        if (posibleNum.charAt(0) != '-') {
            i=1;
            
        }else{ 
            i = 0;
        }
            for (; i < posibleNum.length() && esUnNum; i++){
                char c = posibleNum.charAt(i); 
                esUnNum = c < '0' || c > '9';
            }
       
        return esUnNum;
    }
}
// integer.parseInt("+2347"); devuelve 2347. utilizar string.length()