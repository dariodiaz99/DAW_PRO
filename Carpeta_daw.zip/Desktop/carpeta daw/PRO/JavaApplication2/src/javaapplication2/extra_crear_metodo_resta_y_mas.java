/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication2;

import java.util.Scanner;

/**
 *
 * @author dario
 */
public class extra_crear_metodo_resta_y_mas {
    public static int resta(int a, int b){
    int resta;
    if (a > b){
        resta = a - b;
    }else{
        resta = b - a;
    }
    return resta;
    }
    
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int primerNumero, segundoNumero, resultado;
        System.out.println("Introduce el primer número: ");
        primerNumero = sc.nextInt();
        System.out.println("Introduce el segundo número: ");
        segundoNumero = sc.nextInt();
        resultado = resta(primerNumero, segundoNumero);
        System.out.println("Resta: " + resultado);
        cajaTexto("Hola Dario!");
    }
    
    public static String cajaTexto(String str){ 
        String textoDevuelto = "";
        int n = str.length(); 
        for (int i = 0; i < n + 4; i++){ 
            textoDevuelto += "#";//sout("#");
        } 
        textoDevuelto += "\n";
        //System.out.println();
        textoDevuelto += "# " + str + " #"; 
        //System.out.println("# " + str + " #");
        for (int i = 0; i < n + 4; i++){
            textoDevuelto += "#";
              //System.out.print("#");
        } 
        textoDevuelto += "\n";
           //System.out.println();
    return textoDevuelto;
    }
    
    
    public static int sumar(int a, int b){ 
        int c; 
        c = a + b;
        return c;
    }
}
