/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication2;

import java.util.Scanner;

/**
 *
 * @author dario
 */
public class practica22 {
    public static void main(String[] args) {
        Scanner sc = new Scanner (System.in);
        System.out.println("Dame el valor de n");
        int n = sc.nextInt();
        
        System.out.println("Dame el valor de a, valor por el que vamos a multiplicar el anterior número");
        int a = sc.nextInt();
        int resultado = 0;
        
        resultado = multiplicar(n, a);
        System.out.println("multiplicacion: " + resultado);
    }

    private static int multiplicar(int n, int a) {
        int contador = 0, result = n;
        if (n < 0) {
            n = 0 - n;
            contador++;
        }
        
        if (a < 0) {
            a = 0 - a;
            contador++;
        }
        
        if (a > 1) 
            result = multiplicar(n, a - 1) + n;
        else if (n == 0 || a == 0)
            result = 0;
        
        if (contador == 1)
            result = 0 - result;
        
        return result;
    }
 
        
}
