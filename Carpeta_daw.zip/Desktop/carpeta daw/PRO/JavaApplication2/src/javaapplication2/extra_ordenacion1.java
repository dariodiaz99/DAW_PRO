/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication2;

/**
 *
 * @author dario
 */
public class extra_ordenacion1 {
    /*
    PERMUTAR
    */
    public static void main(String[] args) {
        int array[] = {1, 2, 3, 4};
        permutadorArray(array, 0);
        System.out.println(contador);
    }
    
    private static void permutadorArray(int[] array, int posicion){
        if(posicion < array.length - 1){
            for (int i = posicion; i < array.length; i++) {
                int temp = array[posicion];
                array[posicion] = array[i];
                array[i] = temp;
                permutadorArray(array, posicion+1);
                temp = array[posicion];
                array[posicion] = array[i];
                array[i] = temp;
            }
        }else{
            mostrarArray(array);
            contador++;
        }
    }
    static int contador = 0;
    
    private static void mostrarArray(int[] array) {
        System.out.print("[");
        for (int i = 0; i < array.length; i++) {
            System.out.print(array[i] + " ");
        }
            System.out.println(" ]");
    }
}