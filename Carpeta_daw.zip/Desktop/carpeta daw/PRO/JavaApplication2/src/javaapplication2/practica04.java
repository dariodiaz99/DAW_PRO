/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication2;

import java.util.Scanner;

/**
 *
 * @author Dario Diaz <your.name at your.org>
 */
public class practica04 {
    public static boolean numValido(int num) {
        boolean numValido = false;
        if (num > 20 || num < 50 && num % 3 == 0) {
            numValido = true;
        }
        return numValido;
    }

    public static void main(String[] args) {
        int num;
        Scanner cin = new Scanner(System.in);
        do{
            System.out.println("Introducir un número: ");
            num = cin.nextInt();
        }while (!numValido(num));
        System.out.println("El número cumple con los requisitos. Puede continuar");
    }
}
