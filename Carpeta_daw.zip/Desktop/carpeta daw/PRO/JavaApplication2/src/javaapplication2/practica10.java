/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication2;

import java.util.Scanner;

/**
 *
 * @author Dario Diaz
 */
public class practica10 {
    public static void main(String[] args) {
        System.out.println("Introduce cinco numeros");
        Scanner entrada = new Scanner(System.in);
        int numeros[] = new int[5];

        System.out.println("Guardando los datos del array");
        for (int i = 0; i < 5; i++) {
            System.out.println((i + 1) + ". Introduce un numero");
            numeros[i] = entrada.nextInt();
            System.out.println("array" + "[" + i + "]" + " " + numeros[i]);
        }

        double media = 0.0;
        for (int i = 0; i < numeros.length; i++) {
            media += numeros[i];
        }
        media = media / numeros.length;
        System.out.println("La media es: " + media);
    }
}
