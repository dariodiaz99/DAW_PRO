/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication2;

import java.util.Random;

/**
 *
 * @author dario
 */
public class practica03_aleatorio {
    public static void main(String[] args) {
        int num;
        do{
            num = aleatorio(25,45);
            System.out.println(num);
        }while( num != 35 );
    }   

    public static int aleatorio(int num1, int num2){
        int temp = num2; 
        num2 = num1;
        num1 = temp;
        Random rnd = new Random();
        int aleatorio = rnd.nextInt(num1 - num2 +1)+num2;
        
        return aleatorio;
    }
}