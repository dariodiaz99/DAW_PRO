/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication2;

import java.util.Scanner;

/**
 *
 * @author Dario Diaz
 */
public class practica11 {
     public static void main(String[] args) {
        System.out.println("Introduce cinco numeros");
        Scanner entrada = new Scanner(System.in);
        int array[] = new int[5];

        System.out.println("Guardando los datos del array");
        for (int i = 0; i < 5; i++) {
            System.out.println((i + 1) + ". Introduce un numero");
            array[i] = entrada.nextInt();
            System.out.println("array" + "[" + i + "]" + " " + array[i]);
        }

        double media = 0.0;
        for (int i = 0; i < array.length; i++) {
            media += array[i];
        }
        media = media / array.length;
        System.out.println("La media es: " + media);

        int varianza = 0;
        for (int i = 0; i < array.length; i++) {
            double num = array[i] - media;
            varianza += Math.pow(num, 2);
        }
        varianza /= 5;
        System.out.println("la varianza es: " + varianza);
    } 
}
