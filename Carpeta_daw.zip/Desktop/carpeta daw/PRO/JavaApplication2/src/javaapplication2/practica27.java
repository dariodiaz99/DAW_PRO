/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication2;

/**
 *
 * @author dario
 */
public class practica27 {
    static int contador = 0;

    public static void main(String[] args) {
        int base = 10;
        int exponente = 1;
        System.out.println(potencia(10, exponente));
    }

    public static double potencia(int base, int exponente) {
        contador ++;
        int resultado = 0;
        int pow1 = exponente/2;
        int pow2 = exponente/2 + exponente%2;
        
        if (exponente == 0) {
            return 1;
        } else if (exponente == 1) {
            return base;
        } else{
            int parcial = (int)potencia(base, pow2/2);
            resultado = parcial*parcial;
            if(exponente%2 !=0){
                resultado *=base;
            }
            resultado = (int)parcial*parcial * (int)potencia(base, pow2);
        }
        return  resultado;
    }
}
