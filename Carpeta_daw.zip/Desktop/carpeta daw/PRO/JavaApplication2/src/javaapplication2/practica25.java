/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication2;

/**
 *
 * @author dario
 */
public class practica25 {
  static int sumarArray(int array[]){
      int suma = 0;
      int array2[] = null;
      try{
        array2 = new int[array.length -1];
        for (int i = 0; i < array2.length; i++) {
            array2[i] = array[i];
        }
        int ultimoDato = array[array.length -1];
        
        suma = sumarArray(array2)+ ultimoDato;
      }catch(Exception ex){
          suma = array[0];
      }
      return suma;
  }
    public static void main(String[] args) {
        int array[] = {1, 2, 3, 4, 5};
        System.out.println(sumarArray(array));
    }
}
