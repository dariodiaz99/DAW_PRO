/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication2;


import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author dario
 */
public class practica09 {
    public static void main(String[] args) {
        final int SIZE = 10;
        
        System.out.println("Insertamos " + SIZE + " números pares aleatorios");
        int []array = new int[SIZE];
        int min = 100;
        int max = 0;
        
        generarArrayAleatorio(array);
        for (int j = 0; j < array.length; j++) {
                int k = array[j];   
            }
        
        for (int i = 0; i < array.length; i++) {
           
           if (min > array[i]){
               min = array[i];
           }
           
           if(max < array[i]){
               max = array[i];
           }
           
           System.out.println("array[" + i + "] = " + array[i]);
            
        }
        System.out.println("minimo = " + min + " maximo = " + max);
            /*
            if (aleatorio % 2 == 0){
                array[i] = aleatorio;
            }else{
                i--;
            }
            */    
        }

    private static void generarArrayAleatorio(int[] array) {
        Random rnd = new Random();
        
        
        for (int i = 0; i < array.length; i++) {
            int aleatorio = rnd.nextInt(48) * 2 + 2;
            array[i] = aleatorio;
        }
    }
    }         
