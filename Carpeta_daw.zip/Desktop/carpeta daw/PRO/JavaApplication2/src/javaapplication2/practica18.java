/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication2;

import java.util.Arrays;
import java.util.Scanner;

/**
 *
 * @author dario
 */
public class practica18 {
//    public static void main(String[] args) {
//        int array[] = {5, 10, 4, 15, 13, 11};
//        int k = 0;
//        int n = max(array);
//        int helper[] = new int [n + 1];
//        for (int i = 0; i < array.length; i++) {
//            int num1 = array[i];
//            for (int j = 0; j < array.length; j++) {
//                helper[k] = array[i] - array[j];
//                k++;
//            }
//        }
//        for (int m = 0; m < helper.length; m+=7) {
//            helper[m] = 100;
//        }
//        System.out.println(helper[k]);
//    }
//    public static int max(int[] array){
//        int max = array[0];
//        for (int i = 0; i < array.length; i++) {
//            if(max < array[i]){
//                max = array[i];
//            }
//        }
//        return max;
//    }
    
    public static void scannerArray(int array[]) {
        Scanner sc = new Scanner(System.in);
        for (int i = 0; i < array.length; i++) {
            System.out.print("Introduce el numero " + (i + 1) + ": ");
            array[i] = sc.nextInt();
        }
    }
    
    public static void main(String[] args) {
        int[] array = new int[5];
        int[] helper = new int[5];
        int[] menor = new int[5];
        scannerArray(array);
        int distaciaMenor = Math.abs(array[0] - array[1]);
        int restaMenor, restaDef = 0;

        for (int i = 0; i < array.length; i++) {
            for (int j = 0; j < array.length; j++) {
                if (array[i] != array[j]) {
                    restaMenor = Math.abs(array[i] - array[j]);
                    if (restaMenor <= distaciaMenor) {
                        distaciaMenor = restaMenor;
                        helper[j] = restaMenor;
                        restaDef = restaMenor;
                    }
                }
            }
        }
        for (int k = 0, j = 0; k < helper.length; k++) {
            if (restaDef == helper[k]) {
                menor[j] = array[k];
                j++;
            }
        }
        Arrays.sort(menor);
        System.out.print("Las distacias menores son: ");
        for (int i = 0; i < menor.length; i++) {
            if (menor[i] > 0) {
                System.out.print(menor[i] + " ");
            }
        }
        System.out.println("");
    }
}
