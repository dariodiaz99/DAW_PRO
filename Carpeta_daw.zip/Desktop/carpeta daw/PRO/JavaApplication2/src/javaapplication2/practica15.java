/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication2;

import java.util.Random;

/**
 *
 * @author dario
 */
public class practica15 {
    public static void main(String[] args) {
        String numerosNaipes[] = {"1", "2", "3", "4", "5", "6", "7", "sota", "caballo", "Rey"}; 
        /*
        String numerosNaipes[] = new String[10];
        for (int i = 0; i < 7; i++){
            numerosNaipes[i] = ""+(i+1);
        }
        numerosNaipes[7] = "Sota";
        numerosNaipes[8] = "Caballo";
        numerosNaipes[9] = "Rey";
        */
        
        String palosNaipes[] = {"Oro", "Copas", "Bastos", "Espadas"};
        
        Random rnd = new Random();
        int numNaipe = rnd.nextInt(numerosNaipes.length);
        int numPalo = rnd.nextInt(palosNaipes.length);
        
        System.out.println(numerosNaipes[numNaipe] + " de " + palosNaipes[numPalo]);   
    
    }
     
}
