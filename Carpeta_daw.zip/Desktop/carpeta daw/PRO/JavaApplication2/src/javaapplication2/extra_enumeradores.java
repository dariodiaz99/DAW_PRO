/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication2;

/**
 *
 * @author dario
 */
public class extra_enumeradores {
    public enum Demarcacion{
        PORTERO, DEFENSA, CENTROCAMPISTA, DELANTERO
    }
   
    public static void main(String[] args) {
         int numeroDelJugador= 17;
         String nomDelJugador = "Alvaro";
         Demarcacion posicionDelJugador = Demarcacion.DELANTERO;
         System.out.println("nueva posicion: "+ posicionDelJugador);
         posicionDelJugador = Demarcacion.CENTROCAMPISTA;
         System.out.println("nueva posicion: " + nomDelJugador + "" + numeroDelJugador + "" + posicionDelJugador);
    }
}
