/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication2;

import java.util.Scanner;

/**
 *
 * @author Dario Diaz <your.name at your.org>
 */
public class practica14 {
        public static void main(String[] args) {
        Scanner cin = new Scanner(System.in);
        int cantidadNum = 10;
        int array[] = new int[cantidadNum];
        System.out.println("Introduce " + cantidadNum + " numeros");

        for (int i = 0; i < array.length; i++) {
            array[i] = cin.nextInt();
        }

        //Ordenar array
        for(int i=0;i<(array.length-1);i++){
            for(int j=i+1;j<array.length;j++){
                if(array[i]>array[j]){
                    int aux=array[i];
                    array[i]=array[j];
                    array[j]=aux;
                }
            }
        }
    }
    public static String mostrarArray(int[] array3) {
        String strArray = "[";
        for (int i = 0; i < array3.length; i++) {
            strArray += array3[i] + " ";
        }
        strArray += "]";
        System.out.println(strArray);
        return strArray;
    }
}
