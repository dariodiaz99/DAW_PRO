/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication2;

/**
 *
 * @author dario
 */
public class practica29 {
        public static int menorRecursivo(int[] array) {
        int resultado;
        if (array.length == 2) {
            if (array[0] < array[1]) {
                resultado = array[0];
            } else {
                resultado = array[1];
            }
        } else if (array.length == 1) {
            resultado = array[0];
        } else {

            int candidato = array[0];
            int array2[] = new int[array.length - 1];
            for (int i = 0; i < array2.length; i++) {
                array2[i] = array[i + 1];
            }

            int resultadoRecursivo = menorRecursivo(array2);
            if (candidato < resultadoRecursivo) {
                resultado = candidato;
            } else {
                resultado = resultadoRecursivo;
            }
        }
        return resultado;
    }

    public static void main(String[] args) {
        int array[] = {5, 2, 6, 8, 21, 9, 12, 14};
        System.out.println("El menor numero del array recursivamente es: " + menorRecursivo(array));
    }
}
