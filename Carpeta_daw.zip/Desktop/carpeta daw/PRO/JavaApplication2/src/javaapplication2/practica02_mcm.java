/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication2;

import java.util.Scanner;

/**
 *
 * @author dario
 */
public class practica02_mcm {
    
    public static void main(String[] args) { 
        Scanner cin = new Scanner(System.in);
        System.out.println("Cálculo de MCD para dos números");
        System.out.print("Número 1: ");
        int num1 = cin.nextInt();
        System.out.print("Número 2: ");
        int num2 = cin.nextInt();
        String solucion = "MCM: " + num1*num2/mcd(num1,num2); System.out.println(solucion);
        // mcm (a, b) = a*b/mcd(a,b)
    }
    
    //public static int mcm(int num1, int num2){
        
     //   return num1*num2/mcd(num1,num2);
    //}    
    static int mcd(int dividendo, int divisor){
        int resultado, resto;
        do{
        resto = dividendo % divisor;
            if(resto != 0){
                dividendo = divisor;
                divisor = resto;
            }
        }while (resto != 0);
            resultado = divisor;
        return resultado;
    
    }
    
}
