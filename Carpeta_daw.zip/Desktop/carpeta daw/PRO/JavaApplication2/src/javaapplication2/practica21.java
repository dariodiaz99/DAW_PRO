/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication2;

import java.util.Scanner;

/**
 *
 * @author Dario Diaz
 */
public class practica21 {
    static int deUnoaCien(int num1) throws ArithmeticException {
        if (num1 < 1 || num1 > 100) {
            throw new ArithmeticException("Error, el numero debe estar entre 1 y 100");
        }
        return num1;
    }

    public static void main(String[] args) {
        System.out.println("Introducir dos números entre 1 y 100: ");
        Scanner sc = new Scanner(System.in);
        int num1 = sc.nextInt();
        int num2 = sc.nextInt();
        try {
            deUnoaCien(num1);
        } catch (Exception ex) {
            System.out.println(ex);
        }
    }
}
