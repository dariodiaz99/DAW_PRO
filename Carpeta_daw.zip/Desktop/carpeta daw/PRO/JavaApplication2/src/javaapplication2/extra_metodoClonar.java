/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication2;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author dario
 */
public class extra_metodoClonar {
    public static int[] clonarArray(int[] array){
        int []copia = new int[array.length];
        for (int i = 0; i < array.length; i++) {
            copia[i] = array[i];
            
        }
        return copia;
    }
    
    public static void generarArrayAleaorio(int[] array){
      Random rnd = new Random();
      for (int i = 0; i < array.length; i++){
          int dato = rnd.nextInt(49) * 2 + 2;
          array[i] = dato;
      }
       
    }
    /*
    int posMin= 0 , posMax=0;
    for (int i = 1; i < array.length; i++){
        if (array[posmin] > array[i]){
            array[posmin] = array[i];
        }
        if (array[posmax] < array [i]){
            array[posmax] = array[i]
        }
    
    }
    
    */
    
    public static void main(String[] args) {
        final int SIZE = 10;
        
        Scanner sc = new Scanner(System.in);
        int[]array = new int[SIZE];
        
        int[]array3 = clonarArray(array);
        array3[2] = 8;
        
        System.out.println("array3");
        System.out.println(mostrarArray(array3));
        
        System.out.println("array");
        System.out.println(mostrarArray(array));
       
    }

    private static String mostrarArray(int[] array3) {
        String strArray = "[ ";
        for (int i = 0; i < array3.length; i++) {
            strArray += array3[i] + " ";
        }
        strArray += "]";
        return strArray;
    }
   
}
