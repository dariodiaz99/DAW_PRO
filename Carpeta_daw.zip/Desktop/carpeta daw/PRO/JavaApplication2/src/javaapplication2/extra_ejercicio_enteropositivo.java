/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication2;

import java.util.Scanner;

/**
 *
 * @author dario
 */
public class extra_ejercicio_enteropositivo {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Dame un número entero positivo: ");
        String posibleNum = sc.nextLine();
        boolean esUnNum = isInt(posibleNum);

       if(esUnNum) {
           System.out.println("Es un número entero positivo.");
       }else{
           System.out.println("No es un número entero positivo.");
       }
    }

    private static boolean isInt(String posibleNum) {
        boolean esUnNum = true;
        int i=0;
        if (posibleNum.charAt(0) == '-' || posibleNum.charAt(0) == '+') {
            i = 1;
        }
        for (; i < posibleNum.length() && esUnNum; i++) {
            char c = posibleNum.charAt(i);
            esUnNum = c >= '0' && c <= '9';
        }
        return esUnNum;
    }
}
