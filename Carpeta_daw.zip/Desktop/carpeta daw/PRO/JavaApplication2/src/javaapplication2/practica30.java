/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication2;

/**
 *
 * @author dario
 */
public class practica30 {
    
    static double impar(int num){
        double resultado = 0;
        if(num == 1){
            resultado = 1;
        }else if(num % 2 == 0){
            resultado = par(num);
        }else{
            resultado = par(num-1) + 1 / (double) num;
        }
        return resultado;
    }
    
    static double par(int num){
        double resultado = 0;
        if(num % 2 != 0){
            resultado = impar(num);
        }else{
            resultado = impar(num-1) - 1 / (double) num;
        }
        return resultado;
    }
    public static void main(String[] args) {
        System.out.println(par(20));
        System.out.println(impar(20));
    }
}
