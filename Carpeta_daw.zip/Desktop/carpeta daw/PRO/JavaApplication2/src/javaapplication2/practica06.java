/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication2;

import java.util.Scanner;

/**
 *
 * @author Dario Diaz <your.name at your.org>
 */
public class practica06 {
    public static int combinatoria (int num1, int num2){
        if(num2>num1){
        int temp = num1;
        num1 = num2;
        num2 = temp;
        }
    return factorial(num1)/(factorial(num1-num2)*factorial(num2));
    }
        
    public static int factorial(int num){
        int resultado = 1;
        while(num > 1){
            resultado *= num;
            num--;
        }
        return resultado;
    }
    
    public static void main(String[] args) {
        System.out.println("Dame dos numeros sus correspondientes factoriales y su combinación");
        Scanner sc = new Scanner(System.in);
        int num1 =sc.nextInt(), num2 = sc.nextInt();
        System.out.println("Factoriales ===========> \nFactorial del primer numero: " + factorial(num1) + " \nFactorial del segundo numero: " + factorial(num2));
        System.out.println("Combinación: " + combinatoria(num1, num2));
    }
}
