/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication2;

import java.util.Scanner;

/**
 *
 * @author dario
 */
public class practica05 {
    
    public static void main(String[] args) {
        System.out.println("dame dos numeros");
        Scanner sc = new Scanner(System.in);
        int num1 = sc.nextInt(), num2 = sc.nextInt();
        System.out.println("Factoriales ===========> \nFactorialdel primer numero: " + factorial(num1)
                + " \nFactorial del segundo numero: " + factorial(num2));
    }
    
    
    static long factorial(int num){
        long retorno = 1;
        if ( num == 0 ) {
            retorno = 1;
        }else{
            for (int i = 0; i < num; i++) {
                retorno *= (i+1);
            }
        } 
        return retorno;
    }
}
