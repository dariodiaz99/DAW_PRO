/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication2;

import java.util.Scanner;

/**
 *
 * @author dario
 */
public class practica08 {
    
    public static void main(String[] args) {
        
        final int SIZE = 3;
        
        System.out.println("Introduce " + SIZE + " números");
        Scanner sc = new Scanner(System.in);
        int []array = new int[SIZE];
        
        for (int i = 0; i < array.length; i++) {
            System.out.println("dame el número: "+ (i+1));
            array[i] = sc.nextInt();
        }
        
        for (int i = 0; i < array.length; i++) {
            System.out.println("pos: " + i + " array[ " + i + " ]= " + array[i]);
        }
    }
   
}
