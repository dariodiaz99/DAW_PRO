/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication2;

import java.util.Random;

/**
 *
 * @author Dario Diaz <your.name at your.org>
 */
public class practica13 {
    public static void main(String[] args) {
        Random rnd = new Random();
        int array1[] = new int[20];
        int[] array2 = {101, 101, 101, 101, 1001};
        int[] indice = new int[5];
        for (int i = 0; i < array1.length; i++) {
            array1[i] = rnd.nextInt(100) + 1;
        }
        System.out.println("Valores del array");
        mostrarArray(array1);

        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < array1.length; j++) {
                if (pertenece(array1, array2, j) == false) {
                    if (array1[j] < array2[i]) {
                        array2[i] = array1[j];
                        indice[i] = j;
                    }
                }
            }
        }
        System.out.println("5 Menores");
        mostrarArray(array2);
        System.out.println("Indices");
        mostrarArray(indice);
    }

    public static boolean pertenece(int array1[], int[] array, int j) {
        for (int i = 0; i < array.length; i++) {
            if (array1[j] == array[i]) {

                return true;
            }

        }

        return false;
    }

    public static void mostrarArray(int array[]) {

        String coma = "";
        System.out.print("[");
        for (int i = 0; i < array.length; i++) {
            coma = (i == array.length - 1) ? "]" : ",";
            System.out.printf(" %d%s", array[i], coma);

        }

        System.out.println("");

    }
}
