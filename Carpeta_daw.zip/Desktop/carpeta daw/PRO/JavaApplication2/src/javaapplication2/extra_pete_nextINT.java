/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication2;

import java.util.Scanner;

/**
 *
 * @author dario
 */
public class extra_pete_nextINT {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("dame algo");
        int num = sc.nextInt();
        boolean huboErrorRepetir = false;
      
        
        do{
            try{
                System.out.println("Dame un num");
                num = sc.nextInt();
                
                huboErrorRepetir = false;
                System.out.println("la division de 5 por tu número es: ");
                int div = 5 / num;
                System.out.println(div);
                return;
                
            }catch(Exception ex){
                
                sc.nextLine();
                huboErrorRepetir = true;
                System.out.println("no has puesto un número válido");
            //}catch(java.lang.ArithmeticException ex){
                
                System.out.println("mal la division por cero");
                System.out.println("introduce num distinto de cero");
                sc.nextLine();
                huboErrorRepetir = true;    
            }finally{
                System.out.println("se ejecuta siempre");
            }
        }while (huboErrorRepetir);
        
            System.out.println("Introdujiste el num:" + num);

            System.out.println("un mensaje");
     
            System.out.println("El programa continua");
    }
}
