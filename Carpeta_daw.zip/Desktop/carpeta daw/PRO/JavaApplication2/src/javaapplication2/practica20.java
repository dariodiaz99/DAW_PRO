/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication2;

import java.util.Scanner;

/**
 *
 * @author Dario Diaz <your.name at your.org>
 */
public class practica20 {
    public static void main(String[] args) {
        int numero = 0;
        boolean numValido = false;
        int division = 0;
        do {
            try {
                System.out.println("Introducir un número: ");
                Scanner sc = new Scanner(System.in);
                numero = sc.nextInt();
                division = 5 / numero;
                numValido = true;
            } catch (Exception ex) {
                System.out.println("Se debe introducir un número válido");
                numValido = false;
            }
        } while (!numValido);
        System.out.println("El número introducido es: " + numero
                + " y la división de 5/" + numero + " da: " + division);
    }
}
