/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication2;

/**
 *
 * @author dario
 */
public class extra_ejercicio {
   /* public static boolean isInt(String posibleNum) {
        boolean esUnNum = true;
        int i=0;
        if (posibleNum.charAt(0) == '-' || posibleNum.charAt(0) == '+') {
            i = 1;
        }
        for (; i < posibleNum.length() && esUnNum; i++) {
            char c = posibleNum.charAt(i);
            esUnNum = c >= '0' && c <= '9';
        }
        return esUnNum;
    }
    
    public static int textToInt(String str){
        int i = 0, numero = 0;
        String sincero = "";
        int negativo = 1;
        if(str.charAt(0) == '-'){
            negativo = -1;
            i = 1;
        }else if( str.charAt(0) == '+'){
            i = 1;
        }
        while( i < str.length() && str.charAt(i) == '0'){
            i++;
        }
        for (; i < str.length(); i++) {
            sincero +P= str.charAt(i);
        }
        if
    }
    
    
    public static void main(String[] args) {
        int num = textToInt("2312");
        System.out.println(num);
    }*/
public static void main(String[] args){ 
    double resultado = 0;
    try{ 
       resultado = division(3,0.0); 
    }catch(Exception ex){ 
       System.out.println(ex); 
    } 
} 
static double division(double a, double b) throws ArithmeticException{ 
    if(b == 0){
        if (a == 0){
            throw new ArithmeticException("indeterminado");
        }else{
            throw new ArithmeticException("Dividido por cero");
        }
    }else{
         return a/b; 
    }
    }
}
