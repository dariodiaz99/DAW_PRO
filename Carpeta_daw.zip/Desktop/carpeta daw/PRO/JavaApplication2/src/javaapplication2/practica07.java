/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication2;

/**
 *
 * @author dario
 */
public class practica07 {
    
    public enum Estacionanio{
        PRIMAVERA, VERANO, OTONIO, INVIERNO
    }
    
    public static void main(String[] args) {
        Estacionanio estacion = Estacionanio.OTONIO;
        System.out.println("Estacion del año " + estacion);
    }
    
}
