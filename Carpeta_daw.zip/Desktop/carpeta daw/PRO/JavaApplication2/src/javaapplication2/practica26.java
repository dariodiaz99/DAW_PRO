/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication2;

import java.util.Scanner;

/**
 *
 * @author dario
 */
public class practica26 {
        public static int multiplicarArray(int array[], int tam) {
        if (tam == 0) {
            return (array[0]);
        }
        return (array[tam] * multiplicarArray(array, tam - 1));
    }

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int tam = 0;
        System.out.println("Tamaño del array ");
        tam = teclado.nextInt();
        int array[] = new int[tam];
        System.out.println("Introduce los numeros del array ");
        for (int i = 0; i < array.length; i++) {
            System.out.println("Escribe un numero: ");
            array[i] = teclado.nextInt();
        }
        System.out.println("La multiplicación de los numeros es: " + multiplicarArray(array, tam - 1));
    }
}
