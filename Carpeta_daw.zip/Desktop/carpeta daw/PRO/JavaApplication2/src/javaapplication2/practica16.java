/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication2;

import java.util.Random;

/**
 *
 * @author dario
 */
public class practica16 {
    public static void main(String[] args) {
            int array[] = new int[10];
            Random rnd = new Random();
            int aleatorio;
            int suma = 0;
            int mediaNum = 0;
            for (int i = 0; i < 10; i++) {
                aleatorio = rnd.nextInt(100);
                array[i] = aleatorio;
                System.out.println(aleatorio);
                suma += array[i];
            }
            System.out.println(" suma " +suma);
            System.out.println("Media " + suma/10);
            //double media = (double)aleatorio / 10;
    }
}
