/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication2;

/**
 *
 * @author dario
 */
public class practica28 {
    public static void main(String[] args) {
        int num = 20;
        try{
            System.out.println(sellar(num));
        }catch (Exception ex){
            ex.printStackTrace();
        }
    }

    private static String sellar(int num) throws Exception {
        String resultado = "";
        if (num < 12){
            throw new Exception("No es un número >= a 12");
        }
        if (num >= 17){
            resultado = sellar(num - 5) + " + 5";
        }else{
            switch(num){
                case 12: resultado = "4 + 4 + 4" ;break;
                case 13: resultado = "4 + 4 + 5" ;break;
                case 14: resultado = "4 + 5 + 5" ;break;
                case 15: resultado = "5 + 5 + 5" ;break;
                case 16: resultado = "4 + 4 + 4 + 4" ;break;
            }
        }
        return resultado;
    }
}
