/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication2;

/**
 *
 * @author dario
 */
public class practica24 {
    
    public static void main(String[] args) {
        System.out.println(sumarCifras(12345, 0));
    }
    
    static int sumarCifras(int num, int contador){
        int cifra = 0;
        int suma = 0;
        if(num <= 9){
            suma = num;
        }else{
            cifra = num % 10;
            suma = cifra + sumarCifras(num/10,contador+1);
        }
        System.out.println("\nInteración: " + contador);
        System.out.println("cifra: " + cifra);
        System.out.println("suma: " + suma);
        System.out.println("------------------------");
        return suma;
    }
    
}
