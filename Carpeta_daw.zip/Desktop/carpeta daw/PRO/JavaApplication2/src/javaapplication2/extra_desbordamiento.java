/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication2;

import java.util.Scanner;

/**
 *
 * @author dario
 */
public class extra_desbordamiento {
    public static void main(String[] args) {
        Scanner sc = new Scanner (System.in);
//        
//        String StrMax;
//        String candidatoEntero = sc.nextLine();
//        StrMax = "" + 2147483647;
//        for (int i = 0; i < candidatoEntero.length(); i++) {
//            StrMax.CharAt(i) < candidatoEntero.charAt(i);
//            
//        }
        String candidato = sc.nextLine();
        String sincero = "";
        int i = 0;
        while (i < candidato.length() && candidato.charAt(i) == 0)
            i++;
        for ( ; i < candidato.length(); i++){
            sincero += candidato.charAt(i);
            System.out.println(sincero.length());
        }
    }
}
