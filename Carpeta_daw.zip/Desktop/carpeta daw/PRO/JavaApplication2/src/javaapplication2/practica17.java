/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication2;

import java.util.Scanner;

/**
 *
 * @author dario
 */
public class practica17 {
    private static String mostrarArray(int[] array) {
        String strArray = "[ ";
        for (int i = 0; i < array.length; i++) {
            strArray += array[i] + " ";
        }
        strArray += "]";
        return strArray;
    }
    public static void main(String[] args) {
        
        int array[] = {5, 2, 12, 14, 8, 9, 11};
        
        int temp;
        for (int i = 0; i < array.length-1; i++) {
            for (int j = i + 1; j < array.length; j++) {
                if(array[i] > array[j]){
                    temp = array[i];
                    array[i] = array[j];
                    array[j] = temp;
                    System.out.println(mostrarArray(array));
                }
            }
        }
        
        /*
        Scanner sc = new Scanner(System.in);
        System.out.println("Introduce la cantidad de números para el array");
        int cantidad = sc.nextInt();
        int array[] = new int[cantidad];
        System.out.println("Escribir los " + cantidad + " números");
        
        for (int i = 0; i < array.length; i++) {
           array [i] = sc.nextInt();
        }   
        int temp;
        for (int j = 0; j < array.length; j++) {
            for (int i = 0; i < cantidad-1; i++) {
                if(array[i] > array[i+1]){
                    temp = array[i];
                    array[i] =  array [i+1];
                    array [i+1] = temp;
                    System.out.println(mostrarArray(array));
                }
            }
        }
        */
    }
}