/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication2;

import java.util.Scanner;

/**
 *
 * @author dario
 */
public class extra_busquedaRecursiva {
    public static void main(String[] args) {
        int array[] = {2, 8, 11, 12, 15, 20, 24, 29, 34, 42, 48, 53};
        System.out.println("Dame un número y sabemos si esta premiado");
        Scanner sc = new Scanner(System.in);
        
       // buscarNumRecursiva(array, 12);
       
    }
    
//    static boolean buscarNumRecursiva(int array[],int limInferior,int limSuperior,int num){
//        boolean resultado = false;
//        if(limInferior + 1 >= limSuperior){
//            resultado = array[limSuperior] == num || array[limInferior] == num;
//        }else{
//            int medio = (limInferior + limSuperior)/2;
//            if(array[medio] < num){
//                limInferior = 
//            }else{
//                limSuperior =
//            }
//        }
//    }
    
    /*static boolean buscarNumero(int array[], int num){
        int limInferior = 0, limSuperior = array.length-1;
        int i = (limInferior + limSuperior) / 2;
        boolean premiado = false;
        do{
            if (array[i] == num){
                premiado = true;
            }else{
                if(array[i] > num){
                    limInferior = limInferior; //no cambia
                    limSuperior = i + (limInferior + limSuperior)%2;
                }else{
                    limInferior = i - (limInferior + limSuperior)%2;
                    limSuperior = limSuperior;
                }
            } 
        
        }while(!premiado && (limInferior+1 < limSuperior));
    
        if (array[limInferior] == num || array[limSuperior] == num) {
            premiado = true;
            return premiado;
        }*/
}
