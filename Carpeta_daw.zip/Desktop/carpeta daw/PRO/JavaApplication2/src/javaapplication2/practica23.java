/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication2;

import java.util.Scanner;


/**
 *
 * @author dario
 */
public class practica23 {
    
    public static void main(String[] args) {
        Scanner sc = new Scanner (System.in);
        System.out.println("Dame un numero para invertir");
        System.out.println(invertir(sc.nextInt()));;
    }
    
    static int invertir(int num) {
        String strNum = "" + num;
        String strResultado = "";
        
        if (strNum.length() > 1){
            strResultado = ""+invertir(Integer.parseInt(strNum.substring(1))) + strNum.charAt(0);
        }else{
            strResultado = strNum;
        }
        return Integer.parseInt(strResultado);
    }
    
}
