/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication2;

/**
 *
 * @author dario
 */
public class extra_funcion_ordenar_helper {
    public static void main(String[] args) {
        
        int array[] = {1, 1, 2, 2, 3, 8, 9, 11, 20};
        
        int n = max(array);
        int helper[] = new int[n + 1];
        
        for (int i = 0; i < array.length; i++) {
            if(array[i] > 0){
                int indice = array[i];
                helper[indice]++;
            }
        }
        int k = 0;
        for (int j = 0; j < helper.length; j++) {
            if(helper[j] > 0) {
                array[k++] = j;
                helper[j--]--;
            }
        }
        System.out.println("Organizado");
        
    }
    public static int max(int[] array){
        int max = array[0];
        for (int i = 0; i < array.length; i++) {
            if(max < array[i]){
                max = array[i];
            }
        }
        return max;
    }
}
