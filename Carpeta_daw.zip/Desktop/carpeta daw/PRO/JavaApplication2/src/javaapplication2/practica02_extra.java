/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication2;

import java.util.Scanner;

/**
 *
 * @author dario
 */
public class practica02_extra {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("¿Cuántos números quiere? ");
        int numero = sc.nextInt();

        System.out.print("Introduzca el número 1: ");
        int num1 = sc.nextInt();

        for (int i = 2; i <= numero; i++) {
            System.out.print("Introduzca el número " + i + " : ");
            int num2 = sc.nextInt();
            num1 = mcm(num1,num2);
        }
        System.out.println("El m.c.m entre los números es: " + num1);

    }
    static int mcm (int num1, int num2) {
        int mcm = (num1 * num2) / mcd(num1, num2);
        return mcm;
    }
    static int mcd(int dividendo, int divisor){
        int resultado=1, resto;
        do{
        resto = dividendo % divisor;
            if(resto != 0){
                dividendo = divisor;
                divisor = resto;
            }
        }while (resto != 0);
            resultado = divisor;
        return resultado;

    }
}
