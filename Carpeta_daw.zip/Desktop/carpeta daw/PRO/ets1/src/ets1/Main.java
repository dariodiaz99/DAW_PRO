/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ets1;

import javax.swing.JFrame;
import javax.swing.JLabel;

/**
 *
 * @author dario
 */
public class Main
extends JFrame { 
    public Main (){
        JLabel lblSaludo = new JLabel("Hola Mundo. Creando mi primer ejemplo");
        add (lblSaludo);
        
        this.setSize(200,200);
        this.setTitle("JFrame");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setVisible(true);
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        new Main();
    }

}