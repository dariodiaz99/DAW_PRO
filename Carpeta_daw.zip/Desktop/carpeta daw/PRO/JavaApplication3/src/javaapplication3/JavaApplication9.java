/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication3;

import java.util.Scanner;

/**
 *
 * @author dario
 */
public class JavaApplication9 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
// ejemplo acumulador

//        Scanner cin = new Scanner(System.in); 
//         int total = 0; 
//        for(int i= 0; i<4; i++){ 
//            System.out.println("Introduzca dinero: ");
//            int dinero = cin.nextInt(); 
//            total = total + dinero; //aquí tenemos nuestro acumulador } }
//        }
//        System.out.println("total: "+total);
    

// ejercicio 1   
    
    Scanner sc =  new Scanner (System.in);
        int acumulador = 0, nota = 0, i;
        for (i=0; nota>=0; i++ ){
            acumulador += nota;
            System.out.println("dame nota");
            nota = sc.nextInt();
        }         
        System.out.println(acumulador/(double)i);
   }
}
