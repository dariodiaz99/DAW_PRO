/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication3;

import java.util.Scanner;

/**
 *
 * @author dario
 */
public class JavaApplication8 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
      //  int i;
      //  for (i=0;i<10;i++){
      //      i=400;
       // }
       // System.out.println(i);
       Scanner cin = new Scanner(System.in);
       for(int teclado=0; teclado != 100; teclado= cin.nextInt()){
           System.out.println("has introducido: " + teclado);
           System.out.println("Intro un número: ");
       }
       
                }

}
