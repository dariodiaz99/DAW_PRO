/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication3;

/**
 *
 * @author dario
 */
public class JavaApplication3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        boolean dato = 4 < 9;
            System.out.println(dato);
            
        int a = 2;
            System.out.println(a = 4);
            
        // resta desde la tabla ascii
        
        System.out.println('c'-'a');
        
    }
    
}
