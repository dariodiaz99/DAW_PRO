/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

/**
 *
 * @author dario
 */
public class extra01 {
    //Mostrar la tabal de multiplicar indicada en una variable
        public static void main(String[] args) {
            int tabla = 3;
            System.out.println(tabla + "*1=" + tabla*1);
            System.out.println(tabla + "*2=" + tabla*2);
            System.out.println(tabla + "*3=" + tabla*3);
            System.out.println(tabla + "*4=" + tabla*4);
            System.out.println(tabla + "*5=" + tabla*5);
            System.out.println(tabla + "*6=" + tabla*6);
            System.out.println(tabla + "*7=" + tabla*7);
            System.out.println(tabla + "*8=" + tabla*8);
            System.out.println(tabla + "*9=" + tabla*9);
            System.out.println(tabla + "*10=" + tabla*10);
        }  
}   
