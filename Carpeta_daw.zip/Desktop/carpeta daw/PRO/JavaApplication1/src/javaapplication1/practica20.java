/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

import java.util.Scanner;
/**
 *
 * @author dario
 */
public class practica20 {
    public static void main(String args[]){
        
        System.out.println("Dame el número a dividir");
        Scanner sc = new Scanner(System.in);
        int numero = sc.nextInt();
        int resto = numero % 2;
        
        if(resto == 1){
            System.out.println("el número "+ numero  + " es impar");
        }else{
            System.out.println("el número "+ numero + " es par");
        }
    }
}
