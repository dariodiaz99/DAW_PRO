/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

import java.util.Scanner;
/**
 *
 * @author dario
 */
public class practica22 {
    public static void main(String arg[]){
        System.out.println("Dime un número");
        Scanner sc = new Scanner(System.in);
        int numero = sc.nextInt();
        if (numero < 0 ){
             System.out.println("el número " + numero + " es menor que 0");
        }else if (numero == 0){
             System.out.println("el número " + numero + " es igual que 0");
        }else if (numero > 0 && numero < 10){
             System.out.println("el número " + numero + " es mayor que 0 y menor a diez");
        }else if (numero == 10){
             System.out.println("el número " + numero + " es igual que 10");
        }else if (numero > 10 && numero < 20){
            System.out.println("el número " + numero + " es mayor que 10 y menor que 20");
        }else{
            System.out.println("el número " + numero + " es mayor o igual a 20");
        }
 }
}