/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

/**
 *
 * @author dario
 */
public class practica01 {
    public static void main(String[] args) {
        System.out.println("Hola Mundo! Soy Darío Díaz Farrais y este es mi primera programación");
    }
}
