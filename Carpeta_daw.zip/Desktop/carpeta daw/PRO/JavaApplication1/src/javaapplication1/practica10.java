/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

/**
 *
 * @author dario
 */
public class practica10 {
    public static void main(String args[]){
        boolean dato = 4 < 9;
        System.out.println(dato);
    }
}
