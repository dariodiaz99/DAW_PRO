/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

import java.util.Scanner;

/**
 *
 * @author dario
 */
public class practica45 {
    public static void main(String[] args) {
        Scanner sc = new Scanner (System.in);
        int num;
        num = sc.nextInt();
        int i = 1;
        
        while (num >= i){
            i++;
            while (num % i == 0){
                //System.out.println("resto" + i); variable contador debe aparecer como 2^2,3^4,...
                num /= i;
            }
        }
    }
}
