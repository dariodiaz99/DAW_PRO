/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

/**
 *
 * @author dario
 */
public class practica12 {
    public static void main(String[] args) {
        int a = 1;
        int b = 2;
        int c = 3;
        int temp;
        
        temp = b;
        b = a;
        a = c;
        c = temp;
        
        System.out.println("a " + a + " b " + b + " c " + c);
    }
}
