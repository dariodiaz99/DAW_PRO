/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

import java.util.Scanner;

/**
 *
 * @author dario
 */
public class practica13 {
    public static void main(String args[]){
         System.out.println("Dame una frase");
         Scanner str = new Scanner(System.in);
         String strFrase = str.nextLine();
         
         System.out.println("has escrito");
         System.out.println(strFrase);
         
         System.out.println("Introduzca un número mayor que 5 ");
         Scanner cin = new Scanner(System.in);
         int numero = cin.nextInt();
         System.out.println(numero);
         
         System.out.println("dame otro número");
         int numero2 = cin.nextInt();
         System.out.println(numero2);
         
         System.out.println("Suma de los dos números");
         System.out.println(numero + numero2);
         
    }
}
