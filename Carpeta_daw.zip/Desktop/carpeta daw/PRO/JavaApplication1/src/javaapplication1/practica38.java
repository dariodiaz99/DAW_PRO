/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

import java.util.Locale;
import java.util.Scanner;

/**
 *
 * @author dario
 */
public class practica38 {
    public static void main(String[] args) {
        Scanner cin = new Scanner(System.in);
        cin.useLocale(Locale.ENGLISH);

        System.out.println("Introduzca un número de horas");
        float userTime = cin.nextFloat();
        if (userTime < 0) {
            System.out.println("Introduzca una cantidad de horas positiva");
            System.exit(0);
        }

        int days = (int)userTime / 24;
        userTime -= days * 24;

        int hours = (int)userTime;
        userTime -= hours;

        int minutes = (int)(userTime * 60);
        userTime -= minutes / 60f;

        int seconds = (int)(userTime * 3600);

        if (days > 1)
            System.out.print(days + " dias ");
        else if (days == 1)
            System.out.print(days + " dia ");

        if (hours > 1)
            System.out.print(hours + " horas ");
        else if (hours == 1)
            System.out.print(hours + " hora ");

        if (minutes > 1)
            System.out.print(minutes + " minutos ");
        else if (minutes == 1)
            System.out.print(minutes + " minuto ");

        if (seconds > 1)
            System.out.print(seconds + " segundos");
        else if (seconds == 1)
            System.out.print(seconds + " segundo");

        System.out.println("");
    }

        }
