/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

import java.util.Scanner;

/**
 *
 * @author dario
 */
public class practica25 {
    public static void main(String args[]){
        Scanner sc = new Scanner(System.in);
        
        System.out.println("Introduce una letra");
        char letra = sc.next().charAt(0);
        switch(letra){
            case 'a':
            case 'A':
            case 'e':
            case 'E':
            case 'i':
            case 'I':
            case 'o':
            case 'O':
            case 'u':
            case 'U':
                System.out.println("es vocal");
                break;
            default:
                System.out.println("no es vocal");
        }
    }
}
