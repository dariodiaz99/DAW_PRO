/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

import java.util.Scanner;

/**
 *
 * @author dario
 */
public class practica37 {
    public static void main(String[] args) {
        Scanner sc= new Scanner(System.in);
        
        int cantidadBilletes, dinero=0;
        String tipoMoneda = "los billetes";
        for (int multiplo = 100; multiplo > 0; multiplo/=10){
            for (int num = 5; num > 0; num /= 2){
                int valorBilletes = num*multiplo;
                tipoMoneda = (valorBilletes>=5)?"los billete":"las monedas";
                System.out.println("Dame "+tipoMoneda+" de: "+valorBilletes);
                
                cantidadBilletes = sc.nextInt();
                dinero += cantidadBilletes * valorBilletes;
            }
        }
           System.out.println("Dinero total: " + dinero);
//        Scanner sc = new Scanner(System.in);
//        
//        System.out.println("Dime los billetes que tienes de 500");
//        int quiniento = sc.nextInt();
//        System.out.println("Dime los billetes que tienes de 200");
//        int doscientos = sc.nextInt();
//        System.out.println("Dime los billetes que tienes de 100");
//        int cien = sc.nextInt();
//        System.out.println("Dime los billetes que tienes de 50");
//        int cinquenta = sc.nextInt();
//        System.out.println("Dime los billetes que tienes de 20");
//        int veinte = sc.nextInt();
//        System.out.println("Dime los billetes que tienes de 10");
//        int diez = sc.nextInt();
//        System.out.println("Dime los billetes que tienes de 5");
//        int cinco = sc.nextInt();
//        
//        int cantidadTotal =  (quiniento*500)+(doscientos*200)+(cien*100)+(cinquenta*50)+(veinte*20)+(diez*10)+(cinco*5);
//        System.out.println("Cantidad total en euros: "+cantidadTotal+"€");
//        
//        int totalBilletes = quiniento+doscientos+cien+cinquenta+veinte+diez+cinco;
//        System.out.println("Billetes totales= "+totalBilletes);
    
    

        
    }
}
