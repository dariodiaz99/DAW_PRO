/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

/**
 *
 * @author dario
 */
public class practica31 {
    public static void main(String[] args) {
        int i;
        for(i=0;i<=10;i=i+1){
            System.out.println("5x"+i+"="+5*i);
        }
    }
}
