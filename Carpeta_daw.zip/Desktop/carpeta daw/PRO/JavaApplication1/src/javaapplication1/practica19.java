/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

import java.util.Scanner;
/**
 *
 * @author dario
 */
public class practica19 {
    public static void main(String args[]){
        Scanner sc = new Scanner(System.in);
        
        System.out.println("Introduzca los grados Farenheint");
        int farenheint = sc.nextInt();
        
        int centigrados = (farenheint-32) * (5/9);
        
        System.out.println(centigrados + " centigrados");
        
    }
}
