package javaapplication1;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author dario
 */
public class extra04 {
    public static void main(String[] args) {
        // con variable k
        //for (int i = 0, num = 0, k = 0;k < 100; k++, num = k%10, i = k/10) {
        //    System.out.println((i+1) + "*"+ (num+1) +"="+ (i+1) * (num+1)); 
        //}
        
        // sin variable k
        for (int i = 0, j= 0 ;i < 10; ++j, i += j/10, j %= 10) {
            System.out.println((i+1) + "*"+ (j+1) +"="+ (i+1) * (j+1)); 
        }
    }
}
