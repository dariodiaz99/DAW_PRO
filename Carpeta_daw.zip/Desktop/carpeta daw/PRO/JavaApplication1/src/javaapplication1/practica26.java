/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

import java.util.Scanner;

/**
 *
 * @author dario
 */
public class practica26 {
    public static void main(String[] args) {
        Scanner sc =  new Scanner(System.in);
        System.out.println("Escribeme un dia de la semana de forma numerica(1 al 5)");
        
        int dia = sc.nextInt();
        
        switch(dia) {
            case 1: System.out.println("Es lunes y te toca FOL a primera hora"); break;
            case 2: System.out.println("Es martes y te toca LND a primera hora"); break;
            case 3: System.out.println("Es miércoles y te toca PRO a primera hora"); break;
            case 4: System.out.println("Es jueves y te toca ETS a primera hora"); break;
            case 5: System.out.println("Es viernes y te toca BAE a primera hora"); break;
            default: System.out.println("Por favor, introduce un número del 1 al 5");
                      
        }
        
    }
}
