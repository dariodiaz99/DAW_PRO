/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

import java.util.Scanner;

/**
 *
 * @author dario
 */
public class practica39 {
    public static void main(String[] args) {
        Scanner sc = new Scanner (System.in);
        
        System.out.println("dame un numero de 2 cifras");
        String numero = sc.nextLine();
        String invertido ="";
        
        for (int i = numero.length()-1; i < numero.length(); i--){
           // invertido = "" + numero.charAt(i) + invertido;
           invertido += numero.charAt(i);
           invertido = invertido;
        
        }
        System.out.println("el invertido: " + invertido);
    }
}
