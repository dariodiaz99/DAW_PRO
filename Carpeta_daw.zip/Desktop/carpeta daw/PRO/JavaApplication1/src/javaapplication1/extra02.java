/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

import java.util.Scanner;

/**
 *
 * @author dario
 */
public class extra02 {
    //Con una edad introducida por el usuario mosttrar si es adulto o no
        public static void main(String[] args){
            Scanner cin = new Scanner(System.in);
            int age = cin.nextInt();
            String legal = (age >= 18)?"Adulto":"No adulto";
            System.out.println(legal);
        }
}