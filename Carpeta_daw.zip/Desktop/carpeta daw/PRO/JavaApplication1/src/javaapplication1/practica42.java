/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

import java.util.Scanner;

/**
 *
 * @author dario
 */

public class practica42 {
    public static void main(String[] args) {
        Scanner cin = new Scanner(System.in);
        
        System.out.print("¿Cuanto se cobrará por el encargo?: ");
        int money = cin.nextInt();
        System.out.print("¿Cuántas personas van a trabajar?: ");
        int people = cin.nextInt();
        
      	int time = 0;
        for (int i = 1; i <= people; i++) {
           System.out.print("¿Cuantas horas ha trabajado el trabajador " + i + "?: ");
           time += cin.nextInt();
        }
        System.out.println("La hora de trabajo costará " + 
        (Math.round(money / (float)time * 100))/100f + "€");
   }
}
