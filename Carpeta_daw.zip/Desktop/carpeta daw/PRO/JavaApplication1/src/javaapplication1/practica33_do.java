/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author dario
 */
public class practica33_do {
    public static void main(String[] args) {
        Scanner cin = new Scanner(System.in);
        Random rnd = new Random();
        
        int i = 1, tryCount = 3;
        String pin = "";
        boolean pinCorrect = false;
        do {
            pin += "" + rnd.nextInt(10);
            i++;
        } while (i <= 4);

        System.out.println(pin);
        System.out.println("Introduzca el pin");
        do {
            System.out.print("Tiene " + tryCount + " intento(s): ");
            pinCorrect = (cin.nextLine().equals(pin));
            tryCount--;
        } while (tryCount > 0 && pinCorrect == false);
        if (pinCorrect == true)
            System.out.println("El código es correcto. Bienvenido");
        }
}
