/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

import java.util.Scanner;

/**
 *
 * @author dario
 */
public class practica46 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Dame un numero para convertirlo");
        int numDecimal = sc.nextInt();
        
        int division;
        
        division = numDecimal;
        String strNumBinario = "";
        

//otra forma
        
//        do{
//            resto = division % 2;
//            strNumBinario = "" + resto + strNumBinario;
//      // una forma      
////            if (resto == 0){
////                strNumBinario = "0" + strNumBinario;
////            }else if (resto == 1){
////                 strNumBinario = "1" + strNumBinario;
////            }
//             division /= 2;
//            
//        }while (division != 0);            
//        System.out.println("El número en binario es: " + strNumBinario);
//        
        String strResto = "";
        
        for (division = numDecimal; division > 0;division /= 2){
            strNumBinario = /*strResto + */ (division % 2) + strNumBinario;
        }
        System.out.println("El número en binario es: " + strNumBinario);
    }
}



