/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

import java.util.Scanner;
/**
 *
 * @author dario
 */
public class practica17 {
    public static void main(String args[]){
        final double IGIC = 7/100.0;
        
        System.out.println("Introduce un precio para calcular el igic");
        Scanner sc = new Scanner(System.in);
        double numero = sc.nextInt();
        
        double total = numero * IGIC;
        System.out.println("El IGIC del precio dado es: " + total);
        double total2 = numero + total;
        System.out.println("El precio total con IGIC es: " + total2);
    }
}
