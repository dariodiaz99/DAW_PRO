/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

import java.util.Scanner;

/**
 *
 * @author dario
 */
public class practica16 {
    public static void main(String args[]){
       System.out.println("Dime los metros del lado más largo");
       Scanner scanner = new Scanner(System.in); 
       int metros = scanner.nextInt();
       
       System.out.println("Dime los metros del lado más pequeño");
       Scanner sc = new Scanner(System.in); 
       int metros2 = sc.nextInt();
       
       int area = metros * metros2;
       System.out.println(area + " metros cuadrados");
      
       int ladoEnCm = metros * 100;
       int baseEnCm = metros2 * 100;
       int areaCm = ladoEnCm * baseEnCm;
       
       System.out.println(areaCm + " centímetros cuadrados");
    }
}
