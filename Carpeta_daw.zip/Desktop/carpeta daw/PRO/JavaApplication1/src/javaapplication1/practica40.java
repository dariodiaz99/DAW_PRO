/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

import java.util.Scanner;

/**
 *
 * @author dario
 */
public class practica40 {
    public static void main(String[] args) {
        Scanner cin = new Scanner(System.in);
        
        short num = -5;
        for (System.out.println("¿Cuántas cifras tiene su número?\n"+ "Introduzca un número entre 0 y 999"); num < 0 || num > 999;){
            num = cin.nextShort();
            if (num < 0 || num > 999) {
               System.out.println("Por favor, introduzca un número válido");
            }
        }
        byte pow;
        for (pow = 1; Math.pow(10, pow) < num; pow++);
            System.out.println("El número tiene " + pow + " cifras");
    }
}
