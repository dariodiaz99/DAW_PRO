package javaapplication1;


import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author dario
 */
public class extra05 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        String algo = sc.nextLine();
        int numDecimal = 0;
        
        for (int i = 0, j = algo.length() -1; i < algo.length(); i++, j = algo.length() -1 -i) {
            int digito = algo.charAt(j) - '0';
            
            numDecimal += digito * Math.pow(2,i);
            
        }
        
        System.out.println(numDecimal);
        
    }
}
