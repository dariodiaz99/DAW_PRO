/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

import java.util.Scanner;

/**
 *
 * @author dario
 */
public class practica30 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        String entrada;
        char c;
        do {
           
           int num = (int)(Math.random()*10+10);
           System.out.println(num);
           entrada = sc.nextLine();
           c = entrada.charAt(0);
           
           
        }while ( c == 'c' || c == 'C');
    }
}
