/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

import java.util.Scanner;

/**
 *
 * @author dario
 */
public class practica21 {
    	public static void main(String args[]){
            System.out.println("Dame el número a dividir");
            Scanner sc = new Scanner(System.in);
            int numero = sc.nextInt();
            //int resto = numero % 2;
        
            if(numero %3 == 0  && numero % 5 == 0){
                System.out.println("múltiplo de 3 y 5");
            }else if ( numero %3 != 0 && numero %5 == 0){
                System.out.println("multiplo de ninguno");
            }else if (numero %3 != 0){
            	System.out.println("multiplo de 5 únicamente");
            } else {
                System.out.println("multiplo de 3 únicamente");
            }
    	}       
}
