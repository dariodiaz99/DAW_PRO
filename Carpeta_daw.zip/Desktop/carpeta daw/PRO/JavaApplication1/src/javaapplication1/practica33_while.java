/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author dario
 */
public class practica33_while {
    public static void main(String[] args) {
        Scanner cin = new Scanner(System.in);
        Random rnd = new Random();
        
        int i = 1, tryCount = 3;
        String pin = "";
        boolean pinCorrect = false;
        while (i <= 4){
            pin += "" + rnd.nextInt(10);
            i++;
        }

        System.out.println(pin);
        System.out.println("Introduzca el pin");
        while (tryCount > 0 && pinCorrect == false) {
            System.out.print("Tiene " + tryCount + " intento(s): ");
            pinCorrect = (cin.nextLine().equals(pin));
            tryCount--;
        }
        if (pinCorrect == true)
            System.out.println("El código es correcto. Bienvenido");
    }
}