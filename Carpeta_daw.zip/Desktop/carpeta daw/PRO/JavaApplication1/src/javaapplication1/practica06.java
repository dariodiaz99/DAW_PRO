/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

/**
 *
 * @author dario
 */
public class practica06 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println("L\t M\t X\t J\t V\n" + 
             "FOL\t LND\t PRO\t ETS\t BAE\n"+
             "PRO\t LND\t PRO\t PRO\t BAE\n" +
             "LNT\t ETS\t BAE\t PRO\t BAE\n" +
             "Recreo\t Recreo\t Recreo\t Recreo\t Recreo\n" +
             "LNT\t PRO\t SSF\t BAE\t ETS\n" +
             "SSF\t PRO\t LND\t SSF\t FOL\n" +
             "SSF\t BAE\t LND\t SSF\t FOL\n" 
        );
     
    }
    
}
