/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

import java.util.Scanner;
/**
 * x1= -1 * b + Math.sqrt (b*b -4 *a *c)/(2*a);
 * x2= -1 * b - Math.sqrt (b*b -4 *a *c)/(2*a);
 * @author dario
 */
public class practica23 {
    public static void main(String args[]){
         Scanner sc = new Scanner(System.in);
        
         System.out.println("Dime la variable a");
         double numbera = sc.nextDouble();
         
         System.out.println("Dime la variable b");
         double numberb = sc.nextDouble();
         
         System.out.println("Dime la variable c");
         double numberc = sc.nextDouble();
         double raiz = (numberb*numberb -4 *numbera *numberc);
         
         if (raiz >= 0){
            double discriminante = -1 * numberb + Math.sqrt (numberb*numberb -4 *numbera *numberc)/(2*numbera);
            System.out.println("Valor del discriminante1: " + discriminante);
            double discriminante2 = -1 * numberb + Math.sqrt (numberb*numberb -4 *numbera *numberc)/(2*numbera);
            System.out.println("Valor del discriminante2: " + discriminante2);
         }else{
             System.out.println("No hay solución real");
         }
    }
}
