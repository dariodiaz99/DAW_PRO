/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author dario
 */

public class practica33_for {
    public static void main(String[] args) {
       	Scanner cin = new Scanner(System.in);
        Random rnd = new Random();
        
        String pin = "";
        boolean pinCorrect = false;
        for (int i = 1; i <= 4; i++)
            pin += "" + rnd.nextInt(10);
            System.out.println(pin);
            System.out.println("Introduzca el pin");
        
        for (int tryCount = 3; tryCount > 0 && pinCorrect == false; tryCount--) {
            System.out.print("Tiene " + tryCount + " intento(s): ");
            pinCorrect = (cin.nextLine().equals(pin));
        }
        
        if (pinCorrect == true)
            System.out.println("El código es correcto. Bienvenido");
    
    }
}

