/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

import java.util.Scanner;
/**
 *
 * @author dario
 */
public class practica24 {
    public static void main(String args[]){
        System.out.println("dame primera letra de tu idioma");
        
        Scanner cin = new Scanner(System.in);
        
        char idioma = cin.next().charAt(0);
        switch(idioma){
            case 'c' : System.out.println("Buenos dias");break;
            case 'i' : System.out.println("Good morning");break;
            case 'f' : System.out.println("Bon jour");break;
            default : System.out.println("no entiendo tu idioma");
        }
    }
}
