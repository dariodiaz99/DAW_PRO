/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

import java.util.Scanner;

/**
 *
 * @author dario
 */
public class practica41 {
    public static void main(String[] args) {
        Scanner cin = new Scanner(System.in);
        
        System.out.println("Introduzca una frase para invertirla");
        String phrase = cin.nextLine();
        
        String invPhrase = "";
        for (int i = phrase.length()-1; i >= 0; i--) {
            invPhrase += phrase.substring(i, (i + 1));
        }
        System.out.println(invPhrase);
    }
}
