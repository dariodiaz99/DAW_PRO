/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

/**
 *
 * @author dario
 */
public class practica27 {
    public static void main(String[] args) {
        int i = 5;
        int n = 0;
        while (n < 10) {
            n = n + 1;
            System.out.println(i + "*" + n + "=" + i * n);
        }
    }
}
