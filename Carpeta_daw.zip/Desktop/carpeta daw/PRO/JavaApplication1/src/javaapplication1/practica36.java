/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

import static java.lang.Math.random;
import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author dario
 */
public class practica36 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Random rnd = new Random();
       
        int tiradas = 0;
        int puntosTotales = 0;
        int tiradasTotales = 0;
        char entrada;
        do {
            tiradasTotales++;
            int aleatorio1 = rnd.nextInt(6) +1;
            int aleatorio2 = rnd.nextInt(6) +1;
            int aleatorio3 = rnd.nextInt(6) +1;
           
            System.out.println("dado1: " + aleatorio1);
            System.out.println("dado2: " + aleatorio2);
            System.out.println("dado3: " + aleatorio3);
          
            int acumulado = aleatorio1 + aleatorio2 + aleatorio3;
            System.out.println("acumulador de puntos: "+acumulado);
            tiradas++;
            System.out.println("Tiradas totales: "+ tiradas);
            puntosTotales += tiradas;
            System.out.println("¿Quieres tirar de nuevo (f para finalizar)?");
            entrada = sc.next().toLowerCase().charAt(0);
        
        }while(entrada != 'f' || entrada != 'F');
        
            System.out.println("el acumulado es: "+puntosTotales);
            System.out.println("obtenido en: " + tiradasTotales + "tiradas");
        
    }
}
