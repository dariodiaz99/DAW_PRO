/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

import java.util.Random;
import java.util.Scanner;


/**
 *
 * @author dario
 */
public class practica43 {
    public static void main(String[] args) {
        System.out.println("Adivina el número secreto");
        Scanner sc = new Scanner(System.in);
        
        Random rnd= new Random();
        int aleatorio = rnd.nextInt(100);
        int num = sc.nextInt();
        int intentos = 0;
        
        if (num == aleatorio){
                System.out.println("Ganador!");
        }
        else{
            System.out.println("Intentalo de nuevo");
            if(num < aleatorio){
                System.out.println(num + " < secreto");
            }else{
                System.out.println(num + "> secreto");
            }
            intentos++;
        }
        while (num != aleatorio);
        System.out.println("Intentalo de nuevo");
    }  
}