package javaapplication1;


import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author dario
 */
public class extra06 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("introduce un número");
        
        int divisor = 2, num = sc.nextInt();
        int potencia = 0;
        boolean salir;
        String mensaje = "", strDivisor = "";
        
        while (num != 1){
            salir = false;
            while (num % divisor == 0){
                potencia++;
                num /= divisor;
                strDivisor = "" + divisor;
                System.out.println(num);
            }
            mensaje += strDivisor + "^" + potencia + "*";
            divisor++;
        }
       mensaje += "1";
        System.out.println(mensaje);
    }
}
